#!/bin/bash
# Tema NEON - estilo hacker, barras animadas
T_NAME="⚡ Neón"
T_TOP="▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀"
T_SEP="▫️▫️▫️▫️▫️▫️▫️▫️▫️"
T_ANIM=("⚡ ▁▂▃" "⚡ ▂▃▅" "⚡ ▃▅▇" "⚡ ▅▇█" "⚡ ▇█▇" "💠 ▓▓▓")
T_ANIM_DELAY=0.2
I_USER="🧑‍💻"; I_KEY="🗝"; I_CAL="🗓"; I_LIM="♾"; I_IP="📡"; I_CRED="💎"
I_OK="💠"; I_ERR="⛔"; I_WAIT="⌛"; I_RENEW="♻️"; I_ONLINE="🔋"
I_SERVER="🧬"; I_PORT="🔗"; I_ADMIN="🛡"
B_USERS="⚡ Usuarios"; B_ADD="⚡ Nuevo SSH"; B_TOKEN="⚡ Token"; B_HWID="⚡ HWID"
B_DEMO="⚡ Demo"; B_RENEW="♻️ Renovar"; B_ONLINE="🔋 Online"; B_DELETE="⛔ Borrar"
B_VPS="🧬 VPS"; B_PORTS="🔗 Puertos"; B_MORE="💠 Más"; B_THEME="🎨 Tema"
B_V2RAY="⚡ V2Ray"; B_PAYLOAD="⚡ Payload"; B_ADMIN="🛡 Admins"; B_BACKUP="💾 Backup"
B_PRICES="💎 Precios"
B_HOME="🏠 Inicio"; B_BACK="◀ Volver"; B_CANCEL="⛔ Cancelar"; B_CONFIRM="💠 Confirmar"
B_PREV="⏪"; B_NEXT="⏩"; B_GEN="🎲 Generar"; B_AGAIN="⚡ Otra"; B_REFRESH="♻️ Refrescar"
B_RENEWBTN="♻️ Renovar"; B_DEL_YES="⛔ Sí, borrar"
B_BACKUP_NOW="💾 Crear backup"; B_RESTORE="📥 Restaurar"
B_ADM_ADD="➕ Agregar"; B_ADM_CRED="💎 Créditos"; B_ADM_KILL="⛔ Quitar"; B_ADM_LIST="📋 Lista"
B_MODE_R="Estándar"; B_MODE_M="Mensual"; B_MODE_Q="Quincenal"
B_DEMO_NORMAL="⚡ Normal"; B_DEMO_TOKEN="🎫 Con token"
B_FAST="⚡ Rápido (30d, 1 conexión)"
