#!/bin/bash
# =====================================================================
#  lib/tg.sh - transporte hacia Telegram
#  Usa curl con --data-urlencode (ShellBot manda el texto sin codificar
#  y se rompe con + % & #). ShellBot queda solo para RECIBIR updates.
#  El token viaja por stdin (-K -) para que no aparezca en "ps".
# =====================================================================

TG_LAST_MID=""

tg_api() {   # metodo clave=valor ...
    local method="$1"; shift
    local -a args=()
    local kv
    for kv in "$@"; do args+=(--data-urlencode "$kv"); done
    printf 'url = "https://api.telegram.org/bot%s/%s"\n' "$BOT_TOKEN" "$method" \
        | curl -s -m 30 -K - "${args[@]}"
}

tg_check() {   # respuesta metodo
    [[ "$1" == *'"ok":true'* ]] && return 0
    [[ "$1" == *"message is not modified"* ]] && return 0
    sb_log "TG ERROR $2: ${1:0:300}"
    return 1
}

tg_mid() { grep -o '"message_id":[0-9]*' <<< "$1" | head -n1 | cut -d: -f2; }

tg_send() {   # chat texto [teclado_json]
    local resp
    resp=$(tg_api sendMessage "chat_id=$1" "text=$2" "parse_mode=HTML" \
        "disable_web_page_preview=true" ${3:+"reply_markup=$3"})
    TG_LAST_MID="$(tg_mid "$resp")"
    tg_check "$resp" sendMessage
}

tg_edit() {   # chat mensaje_id texto [teclado_json]   (si no se puede editar, envia uno nuevo)
    local resp
    resp=$(tg_api editMessageText "chat_id=$1" "message_id=$2" "text=$3" "parse_mode=HTML" \
        "disable_web_page_preview=true" ${4:+"reply_markup=$4"})
    if tg_check "$resp" editMessageText; then
        TG_LAST_MID="$2"
        return 0
    fi
    tg_send "$1" "$3" "$4"
}

tg_answer() {   # callback_id [texto] [alerta true|false]
    [[ -z "$1" ]] && return 0
    tg_api answerCallbackQuery "callback_query_id=$1" ${2:+"text=$2"} ${3:+"show_alert=$3"} >/dev/null
}

tg_delete() { tg_api deleteMessage "chat_id=$1" "message_id=$2" >/dev/null; }
tg_action() { tg_api sendChatAction "chat_id=$1" "action=${2:-typing}" >/dev/null; }

tg_doc() {   # chat archivo [leyenda]
    printf 'url = "https://api.telegram.org/bot%s/sendDocument"\n' "$BOT_TOKEN" \
        | curl -s -m 60 -K - -F "chat_id=$1" -F "document=@$2" ${3:+-F "caption=$3"} >/dev/null
}

# ---------------------------- teclados en linea -----------------------
KB_ROWS=()
jesc() { local s="$1"; s="${s//\\/\\\\}"; s="${s//\"/\\\"}"; printf '%s' "$s"; }

kb_new() { KB_ROWS=(); }

kb_row() {   # "texto" "datos" ["texto" "datos" ...]
    local row="" t d
    while (( $# >= 2 )); do
        t="$(jesc "$1")"; d="$(jesc "$2")"
        row+="${row:+,}{\"text\":\"${t}\",\"callback_data\":\"${d}\"}"
        shift 2
    done
    [[ -n "$row" ]] && KB_ROWS+=("[${row}]")
}

kb_json() { local IFS=,; printf '{"inline_keyboard":[%s]}' "${KB_ROWS[*]}"; }
