#!/bin/bash
# =====================================================================
#  lib/router.sh - enrutador de comandos y botones
#
#  Un modulo se conecta con DOS lineas:
#     cmd_register "agregar add" handler  nivel     # comandos escritos
#     cb_register  "usr"         handler  nivel     # botones (callback_data "usr:...")
#  Niveles: public | reseller | super | dueno
# =====================================================================

declare -A CMD_H=() CMD_L=() CB_H=() CB_L=()

cmd_register() {   # "alias1 alias2" handler nivel   (solo con "/")
    local a
    for a in $1; do
        a="${a#/}"
        CMD_H["/$a"]="$2"; CMD_L["/$a"]="$3"
    done
}

cb_register() { CB_H["$1"]="$2"; CB_L["$1"]="$3"; }

# ------------------------------ contexto ------------------------------
CTX_KIND=""; CTX_UID=""; CTX_CHAT=""; CTX_MID=""; CTX_TEXT=""; CTX_DATA=""
CTX_CBID=""; CTX_USERNAME=""; CTX_ARGS=(); CB=(); CRED=""; UI_MID=""

ctx_from_message() {
    CTX_KIND=msg
    CTX_UID="${message_from_id[$id]:-${message_chat_id[$id]}}"
    CTX_CHAT="${message_chat_id[$id]}"
    CTX_MID="${message_message_id[$id]}"
    CTX_TEXT="${message_text[$id]}"
    CTX_USERNAME="${message_from_username[$id]}"
    CTX_CBID=""; UI_MID=""
}

ctx_from_callback() {
    CTX_KIND=cb
    CTX_UID="${callback_query_from_id[$id]}"
    CTX_CHAT="${callback_query_message_chat_id[$id]}"
    CTX_MID="${callback_query_message_message_id[$id]}"
    CTX_DATA="${callback_query_data[$id]}"
    CTX_USERNAME="${callback_query_from_username[$id]}"
    CTX_CBID="${callback_query_id[$id]}"
    UI_MID="$CTX_MID"          # los botones editan el mensaje donde se pulsaron
}

# El dueno configurado siempre existe como super admin (se autorepara)
ensure_owner() {
    if [[ -n "$OWNER_ID" && "$CTX_UID" == "$OWNER_ID" ]] && ! existe_admin "$OWNER_ID"; then
        set_cred "$OWNER_ID" "X"
    fi
}

nivel_ok() {
    case "$1" in
        public)   return 0;;
        reseller) [[ -n "$CRED" ]];;
        super)    [[ "$CRED" == "X" ]];;
        dueno)    es_dueno "$CTX_UID";;
        *)        return 1;;
    esac
}

# Preferencia de tema por usuario
theme_load() {
    local t="$THEME"
    if [[ -f "$PREF_DIR/$CTX_UID.theme" ]]; then t="$(head -c 20 "$PREF_DIR/$CTX_UID.theme")"; fi
    tema_valido "$t" && [[ -f "$SB_HOME/themes/$t.sh" ]] || t="classic"
    THEME_ACTIVE="$t"
    source "$SB_HOME/themes/$t.sh"
}

# ------------------------------ despacho ------------------------------
dispatch_message() {
    local -a w
    read -r -a w <<< "$CTX_TEXT"
    local cmd="${w[0],,}"
    cmd="${cmd%%@*}"
    CTX_ARGS=("${w[@]:1}")
    [[ -z "$cmd" ]] && return 0

    # Sin "/" nunca es comando: es texto (p. ej. un usuario llamado "demo")
    local handler=""
    [[ "$cmd" == /* ]] && handler="${CMD_H[$cmd]}"
    if [[ -n "$handler" ]]; then
        if ! nivel_ok "${CMD_L[$cmd]}"; then
            if [[ -z "$CRED" ]]; then vista_bloqueado; else vista_sin_permiso; fi
            return 0
        fi
        # cualquier comando escrito cancela un asistente abierto
        flow_active && flow_end
        "$handler"
        return 0
    fi

    # texto libre: si hay un asistente abierto, es la respuesta a su pregunta
    if [[ -n "$CRED" ]] && flow_active; then
        flow_text "$CTX_TEXT"
        return 0
    fi
    if [[ "$cmd" == /* ]]; then
        if [[ -z "$CRED" ]]; then vista_bloqueado; else vista_desconocido; fi
    fi
    return 0
}

dispatch_callback() {
    IFS=: read -r -a CB <<< "$CTX_DATA"
    local pfx="${CB[0]}"
    local handler="${CB_H[$pfx]}"
    if [[ -z "$handler" ]]; then tg_answer "$CTX_CBID"; return 0; fi
    if ! nivel_ok "${CB_L[$pfx]}"; then
        tg_answer "$CTX_CBID" "$L_ERR_NOPERM" true
        return 0
    fi
    # el motor de asistentes contesta el callback por su cuenta (puede mostrar alertas)
    [[ "$pfx" == "fl" ]] || tg_answer "$CTX_CBID"
    "$handler"
}

dispatch_update() {   # usa $id (indice de ShellBot)
    if [[ -n "${callback_query_id[$id]}" ]]; then
        ctx_from_callback
    elif [[ -n "${message_text[$id]}" ]]; then
        ctx_from_message
    else
        return 0
    fi
    [[ -z "$CTX_UID" ]] && return 0
    ensure_owner
    CRED="$(cred_actual "$CTX_UID")"
    theme_load
    if [[ "$CTX_KIND" == "cb" ]]; then dispatch_callback; else dispatch_message; fi
}
