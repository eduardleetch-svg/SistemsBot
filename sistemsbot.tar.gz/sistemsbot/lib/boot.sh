#!/bin/bash
# =====================================================================
#  lib/boot.sh - carga ordenada de todas las capas
#  (se usa desde bot.sh y desde las pruebas)
# =====================================================================
: "${SB_HOME:?SB_HOME no definido}"

# Configuracion: /etc/sistemsbot/bot.conf (instalado) o config/bot.conf (local)
SB_CONF="${SB_CONF:-/etc/sistemsbot/bot.conf}"
[[ -f "$SB_CONF" ]] || SB_CONF="$SB_HOME/config/bot.conf"
[[ -f "$SB_CONF" ]] && source "$SB_CONF"

THEME="${THEME:-classic}"; LANG_BOT="${LANG_BOT:-es}"
ANIMATIONS="${ANIMATIONS:-on}"; PAGE_SIZE="${PAGE_SIZE:-8}"
DEMO_MAX="${DEMO_MAX:-3}"; DEMO_DIAS="${DEMO_DIAS:-2}"
SB_BOTTOKENS="${SB_BOTTOKENS:-$(dirname "$SB_CONF")/bottokens}"

source "$SB_HOME/lib/utils.sh"
source "$SB_HOME/lib/tg.sh"
source "$SB_HOME/lib/flow.sh"
source "$SB_HOME/lib/router.sh"
for f in "$SB_HOME"/core/*.sh;   do source "$f"; done
[[ -f "$SB_HOME/lang/$LANG_BOT.sh" ]] || LANG_BOT=es
source "$SB_HOME/lang/$LANG_BOT.sh"
tema_valido "$THEME" && [[ -f "$SB_HOME/themes/$THEME.sh" ]] || THEME=classic
source "$SB_HOME/themes/$THEME.sh"; THEME_ACTIVE="$THEME"
source "$SB_HOME/views/common.sh"
for f in "$SB_HOME"/views/*.sh;  do [[ "$f" == */common.sh ]] || source "$f"; done
for f in "$SB_HOME"/menus/*.sh;  do source "$f"; done
for f in "$SB_HOME"/flows/*.sh;  do source "$f"; done
for f in "$SB_HOME"/modules/*.sh; do source "$f"; done
unset f
