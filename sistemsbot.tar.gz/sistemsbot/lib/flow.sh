#!/bin/bash
# =====================================================================
#  lib/flow.sh - motor de asistentes (flujos paso a paso)
#
#  Un asistente "X" se define con DOS funciones:
#     flow_X_input  <paso> <valor>   -> logica (valida y avanza)    [flows/X.sh]
#     vp_X          <paso>           -> pantalla del paso (vista)   [views/prompts.sh]
#  El motor guarda el estado en $FLOW_DIR/<id_usuario> (clave=valor).
# =====================================================================

declare -A FD=()
FLOW_TTL="${FLOW_TTL:-900}"     # segundos de vida de un asistente
FLOW_ERR=""

flow_load() {
    FD=()
    local k v f="$FLOW_DIR/$CTX_UID"
    [[ -f "$f" ]] || return 1
    while IFS='=' read -r k v; do
        [[ "$k" =~ ^[A-Za-z0-9_]+$ ]] && FD["$k"]="$v"
    done < "$f"
    return 0
}

flow_save() {
    local k f="$FLOW_DIR/$CTX_UID"
    FD[_ts]="$(date +%s)"
    for k in "${!FD[@]}"; do printf '%s=%s\n' "$k" "${FD[$k]}"; done > "$f"
    chmod 600 "$f" 2>/dev/null
}

flow_active() {
    flow_load || return 1
    if (( $(date +%s) - ${FD[_ts]:-0} > FLOW_TTL )) || [[ -z "${FD[_flow]}" ]]; then
        rm -f "$FLOW_DIR/$CTX_UID"
        return 1
    fi
    return 0
}

flow_end()  { rm -f "$FLOW_DIR/$CTX_UID"; FD=(); FLOW_ERR=""; }
flow_set()  { FD["$1"]="$2"; }
flow_get()  { printf '%s' "${FD[$1]}"; }

# Muestra la pantalla del paso actual y recuerda el mensaje para editarlo despues
flow_prompt() {
    "vp_${FD[_flow]}" "${FD[_step]}"
    FD[_mid]="$UI_MID"
    flow_save
    FLOW_ERR=""
}

flow_goto() { FD[_step]="$1"; flow_prompt; }
flow_err()  { FLOW_ERR="$1"; flow_prompt; }

# flow_start nombre paso [clave=valor ...]
flow_start() {
    local name="$1" step="$2" kv; shift 2
    FD=()
    FD[_flow]="$name"; FD[_step]="$step"; FD[_chat]="$CTX_CHAT"
    for kv in "$@"; do FD["${kv%%=*}"]="${kv#*=}"; done
    flow_prompt
}

# Texto libre del usuario mientras hay un asistente activo
flow_text() {
    flow_load || return 0
    UI_MID="${FD[_mid]}"
    tg_delete "$CTX_CHAT" "$CTX_MID"     # borra lo escrito (claves incluidas)
    "flow_${FD[_flow]}_input" "${FD[_step]}" "$1"
}

# Boton de un asistente: fl:<flujo>:<paso>:<valor>
cb_flow() {
    local sub="${CB[1]}"
    if [[ "$sub" == "cancel" ]]; then
        tg_answer "$CTX_CBID"
        flow_end
        L_NOTE="$L_CANCELLED"
        vista_menu
        return 0
    fi
    if ! flow_active || [[ "${FD[_flow]}" != "$sub" || "${FD[_step]}" != "${CB[2]}" ]]; then
        tg_answer "$CTX_CBID" "$L_EXPIRED" true
        vista_menu
        return 0
    fi
    tg_answer "$CTX_CBID"
    "flow_${FD[_flow]}_input" "${FD[_step]}" "${CB[3]}"
}
