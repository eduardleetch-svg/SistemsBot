#!/bin/bash
# =====================================================================
#  lib/utils.sh - utilidades generales (no hablan con Telegram)
# =====================================================================

# En bash 5.2 el '&' del reemplazo tiene significado especial: lo apagamos.
shopt -u patsub_replacement 2>/dev/null

NL=$'\n'

# Escapa texto para parse_mode HTML
esc() {
    local s="$1"
    s="${s//&/&amp;}"
    s="${s//</&lt;}"
    s="${s//>/&gt;}"
    printf '%s' "$s"
}

# ----------------------------- validaciones ---------------------------
nombre_valido() { local re='^[A-Za-z0-9][A-Za-z0-9_.-]{2,31}$'; [[ "$1" =~ $re ]]; }
nombre_seguro() { local re='^[A-Za-z0-9_][A-Za-z0-9_.-]{0,31}$'; [[ "$1" =~ $re ]]; }
pass_valida()   { local re='^[A-Za-z0-9@#%_.+=!-]{3,64}$'; [[ "$1" =~ $re ]]; }
en_rango()      { [[ "$1" =~ ^[0-9]{1,6}$ ]] && (( 10#$1 >= $2 && 10#$1 <= $3 )); }
id_valido()     { [[ "$1" =~ ^[0-9]{7,}$ ]]; }
tema_valido()   { [[ "$1" =~ ^[a-z0-9_]{1,20}$ ]]; }

gen_pass() { echo "$RANDOM$(date +%s%N)" | md5sum | head -c 8; }

# ------------------------------- rutas --------------------------------
init_paths() {
    DATA_DIR="${DATA_DIR:-/etc/adm-lite}"
    EJE_DIR="${EJE_DIR:-/bin/ejecutar}"
    LIB="$DATA_DIR/liberados"            # id|creditos
    REG="$DATA_DIR/registerBOT.log"      # id_admin|usuario
    dir_user="$DATA_DIR/userDIR"
    DEMOS="$EJE_DIR/demos"               # id|usuario|epoch
    FLOW_DIR="$DATA_DIR/sessions"        # estado de los asistentes
    PREF_DIR="$DATA_DIR/prefs"           # preferencias por usuario (tema)
    LOCK="${LOCK:-/var/lock/sistemsbot.lock}"
    LOCKDIR="${LOCKDIR:-/var/lock/sistemsbot}"
    LOG_FILE="${LOG_FILE:-/var/log/sistemsbot.log}"
    mkdir -p "$DATA_DIR" "$dir_user" "$EJE_DIR" "$FLOW_DIR" "$PREF_DIR" "$LOCKDIR" 2>/dev/null
    chmod 700 "$FLOW_DIR" 2>/dev/null
    touch "$LIB" "$REG" "$DEMOS" 2>/dev/null
}

sb_log() { printf '%s %s\n' "$(date '+%F %T')" "$*" >> "$LOG_FILE" 2>/dev/null; }

ip_srv()     { cat "$EJE_DIR/IPcgh" 2>/dev/null || wget -qO- -T 5 ipv4.icanhazip.com 2>/dev/null; }
pass_token() { if [[ -e "$EJE_DIR/token" ]]; then cat "$EJE_DIR/token"; else echo "ChumoGHPlus"; fi; }
