#!/bin/bash
# =====================================================================
#  flows/extras.sh - asistentes: admins, creditos, restore, v2ray, payload
# =====================================================================

# --------------------------- agregar admin ----------------------------
flow_admin_input() {
    local step="$1" v="$2" i c
    case "$step" in
        id)
            if id_valido "$v"; then flow_set id "$v"; flow_goto cred
            else flow_err "$L_ERR_ID"; fi;;
        cred)
            if [[ "$v" =~ ^([0-9]+|X)$ ]]; then flow_set cred "$v"; flow_goto confirmar
            else flow_err "$L_USE_BUTTONS"; fi;;
        confirmar)
            if [[ "$v" != "ok" ]]; then flow_err "$L_USE_BUTTONS"; return 0; fi
            i="$(flow_get id)"; c="$(flow_get cred)"
            flow_end
            if core_admin_agregar "$i" "$c"; then
                vista_admin_resultado agregado
                vista_avisar_admin "$i" "$L_ADM_ADDED_T"
            else
                vista_error
            fi;;
    esac
}

# ---------------------------- sumar creditos --------------------------
flow_credito_input() {
    local step="$1" v="$2" i n
    case "$step" in
        cant)
            if en_rango "$v" 1 100000; then flow_set cant "$((10#$v))"; flow_goto confirmar
            else flow_err "$L_ERR_AMOUNT"; fi;;
        confirmar)
            if [[ "$v" != "ok" ]]; then flow_err "$L_USE_BUTTONS"; return 0; fi
            i="$(flow_get id)"; n="$(flow_get cant)"
            flow_end
            if core_admin_creditos "$i" "$n"; then
                vista_admin_resultado creditos
                vista_avisar_admin "$i" "$L_ADM_CREDITED_T"
            else
                vista_error
            fi;;
    esac
}

# -------------------------------- restore -----------------------------
flow_restore_input() {
    local step="$1" v="$2"
    if ! [[ "$v" =~ ^https?:// ]]; then flow_err "$L_ERR_URL"; return 0; fi
    flow_end
    ui_anim "$L_RESTORING"
    if core_restore "$v"; then vista_restore_ok; else vista_error; fi
}

# -------------------------------- v2ray -------------------------------
flow_v2ray_input() {
    local step="$1" v="$2" n d
    case "$step" in
        nombre)
            if nombre_valido "$v"; then flow_set nombre "$v"; flow_goto dias
            else flow_err "$L_ERR_NAME"; fi;;
        dias) _flow_dias confirmar "$v";;
        confirmar)
            if [[ "$v" != "ok" ]]; then flow_err "$L_USE_BUTTONS"; return 0; fi
            n="$(flow_get nombre)"; d="$(flow_get dias)"
            flow_end
            ui_anim "$L_CREATING"
            if core_crear_v2ray "$n" "$d"; then
                vista_v2ray
                vista_notificar_dueno "$L_NOTIFY_CREATED" "$n" "$d"
            else
                vista_error
            fi;;
    esac
}

# -------------------------------- payload -----------------------------
flow_payload_input() {
    local step="$1" v="$2" h r c
    case "$step" in
        host)
            if [[ "$v" =~ ^[A-Za-z0-9._-]{3,100}$ ]]; then flow_set host "$v"; flow_goto req
            else flow_err "$L_ERR_HOST"; fi;;
        req)
            if [[ "$v" =~ ^[1-9]$ ]]; then flow_set req "$v"; flow_goto conex
            else flow_err "$L_USE_BUTTONS"; fi;;
        conex)
            if [[ "$v" =~ ^[1-3]$ ]]; then
                h="$(flow_get host)"; r="$(flow_get req)"; c="$v"
                flow_end
                ui_anim "$L_CREATING"
                if core_payload "$h" "$r" "$c"; then
                    tg_doc "$CTX_CHAT" "$R_FILE"
                    vista_payload_ok
                else
                    vista_error
                fi
            else
                flow_err "$L_USE_BUTTONS"
            fi;;
    esac
}
