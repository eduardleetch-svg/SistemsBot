#!/bin/bash
# =====================================================================
#  flows/cuentas.sh - asistentes de cuentas: agregar, token, hwid, demo, renovar
#  Cada asistente = flow_<nombre>_input <paso> <valor>
#  <valor> llega igual por texto escrito o por boton (fl:<flujo>:<paso>:<valor>)
#  Las pantallas estan en views/prompts.sh (vp_<nombre>)
# =====================================================================

# Valida un numero de dias y lo guarda; devuelve 1 si no sirve
_flow_dias() {   # siguiente_paso valor
    if en_rango "$2" 1 3650; then
        flow_set dias "$((10#$2))"
        flow_goto "$1"
    else
        flow_err "$L_ERR_DAYS_IN"
    fi
}

# ------------------------------- SSH ----------------------------------
flow_agregar_input() {
    local step="$1" v="$2" n c d l
    case "$step" in
        nombre)
            if nombre_valido "$v"; then flow_set nombre "$v"; flow_goto clave
            else flow_err "$L_ERR_NAME"; fi;;
        clave)
            if [[ "$v" == "__fast" ]]; then      # rapido: clave auto + valores por defecto
                n="$(flow_get nombre)"; c="$(gen_pass)"; d="${DEFAULT_DIAS:-30}"; l="${DEFAULT_LIMITE:-1}"
                flow_end
                if core_crear_ssh "$n" "$c" "$d" "$l"; then
                    vista_cuenta
                    vista_notificar_dueno "$L_NOTIFY_CREATED" "$n" "$d"
                else
                    vista_error
                fi
                return 0
            fi
            [[ "$v" == "__gen" ]] && v="$(gen_pass)"
            if pass_valida "$v"; then flow_set clave "$v"; flow_goto dias
            else flow_err "$L_ERR_PASS"; fi;;
        dias) _flow_dias limite "$v";;
        limite)
            if en_rango "$v" 1 999; then flow_set limite "$((10#$v))"; flow_goto confirmar
            else flow_err "$L_ERR_LIMIT"; fi;;
        confirmar)
            if [[ "$v" != "ok" ]]; then flow_err "$L_USE_BUTTONS"; return 0; fi
            n="$(flow_get nombre)"; c="$(flow_get clave)"; d="$(flow_get dias)"; l="$(flow_get limite)"
            flow_end
            ui_anim "$L_CREATING"
            if core_crear_ssh "$n" "$c" "$d" "$l"; then
                vista_cuenta
                vista_notificar_dueno "$L_NOTIFY_CREATED" "$n" "$d"
            else
                vista_error
            fi;;
    esac
}

# --------------------------- TOKEN / HWID -----------------------------
# kind = token | hwid   (el segundo paso se llama igual que kind)
_flow_ident_input() {   # kind paso valor
    local kind="$1" step="$2" v="$3" n i d
    case "$step" in
        nombre)
            if nombre_valido "$v"; then flow_set nombre "$v"; flow_goto "$kind"
            else flow_err "$L_ERR_NAME"; fi;;
        "$kind")
            if nombre_valido "$v"; then flow_set "$kind" "$v"; flow_goto dias
            else flow_err "$L_ERR_IDENT"; fi;;
        dias) _flow_dias confirmar "$v";;
        confirmar)
            if [[ "$v" != "ok" ]]; then flow_err "$L_USE_BUTTONS"; return 0; fi
            n="$(flow_get nombre)"; i="$(flow_get "$kind")"; d="$(flow_get dias)"
            flow_end
            ui_anim "$L_CREATING"
            if [[ "$kind" == "token" ]]; then core_crear_token "$n" "$i" "$d"; else core_crear_hwid "$n" "$i" "$d"; fi
            if (( $? == 0 )); then
                vista_cuenta
                vista_notificar_dueno "$L_NOTIFY_CREATED" "$n" "$d"
            else
                vista_error
            fi;;
    esac
}
flow_token_input() { _flow_ident_input token "$1" "$2"; }
flow_hwid_input()  { _flow_ident_input hwid "$1" "$2"; }

# -------------------------------- DEMO --------------------------------
flow_demo_input() {
    local step="$1" v="$2"
    if ! nombre_valido "$v"; then flow_err "$L_ERR_IDENT"; return 0; fi
    flow_end
    ui_anim "$L_CREATING"
    if core_crear_demo "$v"; then
        vista_cuenta
        vista_notificar_dueno "$L_NOTIFY_DEMO" "$v" "$DEMO_DIAS"
    else
        vista_error
    fi
}

# ------------------------------ RENOVAR -------------------------------
flow_renovar_input() {
    local step="$1" v="$2" u m d
    case "$step" in
        modo)
            if [[ "$v" =~ ^[RMQ]$ ]]; then flow_set modo "$v"; flow_goto dias
            else flow_err "$L_USE_BUTTONS"; fi;;
        dias) _flow_dias confirmar "$v";;
        confirmar)
            if [[ "$v" != "ok" ]]; then flow_err "$L_USE_BUTTONS"; return 0; fi
            u="$(flow_get user)"; m="$(flow_get modo)"; d="$(flow_get dias)"
            flow_end
            [[ "$m" == "R" ]] && m=""
            ui_anim "$L_RENEWING"
            if core_renovar "$m" "$u" "$d"; then
                vista_cuenta
                vista_notificar_dueno "$L_NOTIFY_RENEWED" "$u" "$R_DIAS"
            else
                vista_error
            fi;;
    esac
}
