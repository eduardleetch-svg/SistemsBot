#!/bin/bash
# =====================================================================
#  core/sistema.sh - informacion del VPS, puertos, v2ray y payloads
# =====================================================================

core_vps() {
    local ram_t ram_u ram_l
    R_ESTADO=ok
    read -r _ ram_t ram_u ram_l _ < <(LC_ALL=C free -m | awk '/^Mem:/')
    R_RAM_T="$ram_t"; R_RAM_U="$ram_u"; R_RAM_L="$ram_l"
    R_CORES=$(nproc 2>/dev/null || grep -c processor /proc/cpuinfo)
    R_SISTEMA=$(cat /etc/issue.net 2>/dev/null)
    R_CPU=$(ps aux | awk 'NR>1 {s+=$3} END {printf "%.2f%%", s}')
    R_CPUID=$(lscpu 2>/dev/null | awk -F: '/Vendor ID/ {gsub(/ /,"",$2); print $2}')
    R_UPTIME=$(uptime -p)
    R_ARCH=$(uname -m)
}

nombre_servicio() {   # servicio proto
    case "$1" in
        apache2) echo "APACHE";;
        nginx) echo "WEB-NGinx";;
        node) echo "WebSocket";;
        clash) echo "Clash";;
        psiphond) echo "PSIPHON";;
        xray-v2-u|xray-linu) echo "XRAY/UI";;
        v2-ui) echo "V2-UI/WEB";;
        x-ui) echo "XUI/WEB";;
        openvpn) if [[ "$2" == "udp" ]]; then echo "OPENVPN-UDP"; else echo "OPENVPN-TCP"; fi;;
        squid|squid3) echo "SQUID";;
        dropbear) echo "DROPBEAR";;
        python3) echo "SOCKS/PYTHON3";;
        python) echo "SOCKS/PYTHON";;
        obfs-serv) echo "SSR (OBFS)";;
        ss-server) echo "SSR (LIV)";;
        sshd|ssh) echo "SSH";;
        systemd-r) echo "System-DNS";;
        stunnel4|stunnel) echo "SSL";;
        v2ray) echo "V2RAY";;
        xray) echo "XRAY";;
        badvpn-ud) echo "BadVPN";;
        trojan) echo "Trojan-GO";;
        sslh) echo "SSLH";;
        nc.tradit) echo "GenADM-Keys";;
        filebrows) echo "FileBrowser";;
        rpcbind) echo "RPCBind";;
        snell-ser) echo "SNell";;
        dns-serve) echo "SlowDNS";;
        udpServer) echo "UDPServer";;
        hysteria) echo "HysteriaUDP";;
        UDP-Custo) echo "UDP-Custom";;
        php) echo "AToken";;
        *) echo "$1";;
    esac
}

# PRT_TCP[] y PRT_UDP[] con entradas "NOMBRE|puerto"
core_puertos() {
    local name port
    PRT_TCP=(); PRT_UDP=()
    R_ESTADO=ok
    while read -r name port; do
        [[ -z "$port" ]] && continue
        PRT_TCP+=("$(nombre_servicio "$name" tcp)|$port")
    done < <(lsof -V -i tcp -P -n 2>/dev/null | awk '/LISTEN/ {n=split($9,a,":"); print $1, a[n]}' | sort -u)
    while read -r name port; do
        [[ -z "$port" ]] && continue
        PRT_UDP+=("$(nombre_servicio "$name" udp)|$port")
    done < <(lsof -V -i UDP -P -n 2>/dev/null | grep -E 'openvpn|dns-serve|udpServer|hysteria|UDP-Custo' | awk '{n=split($9,a,":"); print $1, a[n]}' | sort -u)
}

# ------------------------------ V2Ray ---------------------------------
core_v2ray_disponible() { [[ -e /etc/v2ray/config.json && -f "$SB_HOME/bot_codes" ]]; }

core_crear_v2ray() {   # nombre dias
    local usr="$1" dia="$2"
    R_ESTADO=ok; R_USER="$usr"
    nombre_valido "$usr" && en_rango "$dia" 1 3650 || { R_ESTADO=invalido; return 1; }
    [[ -f "$SB_HOME/bot_codes" ]] || { R_ESTADO=error; R_MSG="bot_codes"; return 1; }
    R_CRED_NUEVO="$(consumir_credito)" || { R_ESTADO=sin_creditos; return 1; }
    if ! ( cd "$SB_HOME" && bash ./bot_codes v2r_ "$usr" "$dia" ) >/dev/null 2>&1; then
        devolver_credito; R_ESTADO=error; return 1
    fi
    R_LINK="$(cat "$EJE_DIR/${usr}_vmess.txt" 2>/dev/null)"
    R_EXPIRA=$(date '+%d/%m/%Y' -d "+${dia} days")
    R_CRED="$(cred_txt "$R_CRED_NUEVO")"
    R_QR=""
    [[ -e "/var/www/html/${usr}_vmess_qr.png" ]] && R_QR="http://$(ip_srv):81/${usr}_vmess_qr.png"
    return 0
}

# ----------------------------- Payloads -------------------------------
core_payload() {   # host req conex
    local host="$1" req="$2" conex="$3"
    local re_host='^[A-Za-z0-9._-]+$' re_n='^[0-9/]+$'
    R_ESTADO=ok
    [[ "$host" =~ $re_host && "$req" =~ $re_n && "$conex" =~ $re_n ]] || { R_ESTADO=invalido; return 1; }
    [[ -f "$SB_HOME/bot_codes" ]] || { R_ESTADO=error; R_MSG="bot_codes"; return 1; }
    rm -f "$HOME/payloads.txt"
    if ( cd "$SB_HOME" && bash ./bot_codes paygen "$host" "$req" "$conex" ) >/dev/null 2>&1 && [[ -f "$HOME/payloads.txt" ]]; then
        R_FILE="$HOME/payloads.txt"
        return 0
    fi
    R_ESTADO=error
    return 1
}
