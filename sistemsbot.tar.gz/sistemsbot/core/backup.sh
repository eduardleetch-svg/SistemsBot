#!/bin/bash
# =====================================================================
#  core/backup.sh - respaldo y restauracion (solo dueno)
# =====================================================================

core_backup() {
    local file="${BACKUP_FILE:-/root/backup_usuarios.txt}" u sl days passTK n=0 cont=1
    R_ESTADO=ok
    es_dueno "$CTX_UID" || { R_ESTADO=permisos; return 1; }
    passTK="$(pass_token)"
    : > "$file"; chmod 600 "$file"
    while read -r u; do
        [[ -z "$u" ]] && continue
        datos_usuario "$u" "$cont"
        cont=$(( cont + 1 ))
        days=0
        [[ "$u_dias" =~ ^[0-9]+$ ]] && days="$u_dias"
        sl=$(( days + 1 ))
        case "$u_limit" in
            HWID)  echo "$u:$u:HWID:$sl:$u_disp" >> "$file";;
            TOKEN) echo "$u:$passTK:TOKEN:$sl:$u_disp" >> "$file";;
            *)
                [[ "$u_limit" =~ ^[0-9]+$ ]] || u_limit=5
                echo "$u:$u_sen:$u_limit:$sl:$u_sen" >> "$file";;
        esac
        n=$(( n + 1 ))
    done < <(lista_cuentas_bot)
    R_FILE="$file"; R_N="$n"
    return 0
}

core_restore() {   # url
    local url="$1" file="${RESTORE_FILE:-/root/recovery.txt}" ok=0 skip=0
    local r_user r_clave r_limite r_dias r_name real
    local re_url='^https?://[A-Za-z0-9._:/?=&%~+@-]+$' re_lim='^([0-9]+|HWID|TOKEN)$'
    R_ESTADO=ok
    es_dueno "$CTX_UID" || { R_ESTADO=permisos; return 1; }
    [[ "$url" =~ $re_url ]] || { R_ESTADO=invalido; return 1; }
    if ! wget -q -T 20 -t 2 -O "$file" "$url"; then
        rm -f "$file"; R_ESTADO=error; R_MSG="descarga"; return 1
    fi
    chmod 600 "$file"
    while IFS=: read -r r_user r_clave r_limite r_dias r_name <&3; do
        [[ -z "$r_user" ]] && continue
        [[ -z "$r_name" ]] && r_name="$r_user"
        if ! nombre_seguro "$r_user" || ! pass_valida "$r_clave" || ! [[ "$r_limite" =~ $re_lim ]] \
           || ! en_rango "$r_dias" 0 3651 || ! nombre_seguro "$r_name"; then
            skip=$(( skip + 1 )); continue
        fi
        if getent passwd "$r_user" >/dev/null 2>&1; then
            skip=$(( skip + 1 )); continue
        fi
        real=$(( 10#$r_dias - 1 )); (( real < 1 )) && real=1
        case "$r_limite" in
            HWID|TOKEN) crear_cuenta_ext "$r_user" "$r_clave" "$real" "$r_limite" "$r_name" ;;
            *)          crear_cuenta_ext "$r_user" "$r_clave" "$real" "$r_limite" "$r_clave" ;;
        esac
        if (( $? == 0 )); then ok=$(( ok + 1 )); else skip=$(( skip + 1 )); fi
    done 3< "$file"
    rm -f "$file"
    R_OK="$ok"; R_SKIP="$skip"
    return 0
}
