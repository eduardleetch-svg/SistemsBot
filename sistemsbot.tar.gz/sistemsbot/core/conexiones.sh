#!/bin/bash
# =====================================================================
#  core/conexiones.sh - usuarios conectados (logica pura)
# =====================================================================

function_dropb() {
    local pD log="/var/log/auth.log" ok='Password auth succeeded' pid login user
    pD=$(netstat -tulpn 2>/dev/null | awk '/dropbear/ {print $4}' | awk -F: '{print $NF}' | head -n 1)
    [[ -z "$pD" || ! -e "$log" ]] && return 0
    for pid in $(pgrep -f "dropbear.*${pD}"); do
        login=$(grep "dropbear\[${pid}\]" "$log" | grep "$ok" | tail -n 1)
        [[ -z "$login" ]] && continue
        user=$(sed -n "s/.*succeeded for '\([^']*\)'.*/\1/p" <<< "$login")
        [[ -n "$user" ]] && echo "$user $pid"
    done
}

# scope: all (solo super) | mine  ->  CON_USER[] CON_DISP[] CON_N[]
core_conectados() {
    local scope="$1" u n_ssh n_drop n_ovpn tot cont=1 drop_list="" ovpn_list=""
    CON_USER=(); CON_DISP=(); CON_N=()
    R_ESTADO=ok
    local -a src=()
    if [[ "$scope" == "all" ]]; then
        [[ "$CRED" == "X" ]] || { R_ESTADO=permisos; return 1; }
        mapfile -t src < <(lista_cuentas_bot)
    else
        mapfile -t src < <(awk -F'|' -v a="$CTX_UID" '$1==a {print $2}' "$REG" 2>/dev/null | sort -u)
    fi
    [[ -e /etc/default/dropbear ]] && drop_list="$(function_dropb)"
    [[ -e /etc/openvpn/openvpn-status.log ]] && ovpn_list="$(cat /etc/openvpn/openvpn-status.log)"
    for u in "${src[@]}"; do
        [[ -z "$u" ]] && continue
        getent passwd "$u" >/dev/null 2>&1 || continue
        n_ssh=$(pgrep -u "$u" -f "sshd: ${u}" | wc -l)
        n_drop=0
        [[ -n "$drop_list" ]] && n_drop=$(awk -v u="$u" '$1==u' <<< "$drop_list" | wc -l)
        n_ovpn=0
        [[ -n "$ovpn_list" ]] && n_ovpn=$(grep -cwF -- "$u" <<< "$ovpn_list")
        tot=$(( n_ssh + n_drop + n_ovpn ))
        if (( tot > 0 )); then
            datos_usuario "$u" "$cont"
            CON_USER+=("$u"); CON_DISP+=("$u_disp"); CON_N+=("$tot")
        fi
        cont=$(( cont + 1 ))
    done
    return 0
}
