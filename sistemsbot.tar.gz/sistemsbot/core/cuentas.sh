#!/bin/bash
# =====================================================================
#  core/cuentas.sh - cuentas SSH / TOKEN / HWID / DEMO (logica pura)
#  Ninguna funcion de aqui envia mensajes: dejan el resultado en R_*.
#     R_ESTADO = ok | invalido | sin_creditos | existe | no_encontrado | dias | error | max_demos
# =====================================================================

c_valid=""; c_datexp=""

# ----------------------------- utilidades -----------------------------
es_cuenta_bot() {   # uid>=1000, home en /home, shell false
    local l uid home shell
    l="$(getent passwd "$1")" || return 1
    IFS=: read -r _ _ uid _ _ home shell <<< "$l"
    [[ "$uid" =~ ^[0-9]+$ ]] && (( uid >= 1000 )) && [[ "$home" == /home/* ]] && [[ "$shell" == *false ]]
}

# Super admin: cualquier cuenta del bot. Reseller: solo las que el registro dice que creo.
puede_gestionar() {
    local u="$1"
    nombre_seguro "$u" || return 1
    es_cuenta_bot "$u" || return 1
    [[ "$CRED" == "X" ]] && return 0
    awk -F'|' -v a="$CTX_UID" -v u="$u" '$1==a && $2==u {f=1} END{exit !f}' "$REG" 2>/dev/null
}

lista_cuentas_bot() {
    awk -F: '$3 >= 1000 && $6 ~ /^\/home\// && $7 ~ /false/ && $1 != "syslog" {print $1}' /etc/passwd | sort
}

registrar_usuario() {   # usuario (a nombre de CTX_UID)
    (
        flock 9
        awk -F'|' -v a="$CTX_UID" -v u="$1" '$1==a && $2==u {f=1} END{exit !f}' "$REG" \
            || echo "${CTX_UID}|$1" >> "$REG"
    ) 9>"$LOCK"
}

quitar_registro() {     # usuario
    (
        flock 9
        tmp="$(mktemp)"
        awk -F'|' -v u="$1" '$2!=u' "$REG" > "$tmp" && cat "$tmp" > "$REG"
        rm -f "$tmp"
    ) 9>"$LOCK"
}

escribir_userdir() {    # usuario senha limite fecha(YYYY-MM-DD)
    printf 'senha: %s\nlimite: %s\ndata: %s\n' "$2" "$3" "$4" > "$dir_user/$1"
}

# Crea la cuenta con comandos del sistema (sin depender de add_new_user)
crear_cuenta() {   # usuario pass dias limite [nombre_visible]
    local name="$1" pass="$2" days="$3" limit="$4" disp="${5:-$2}" valid hash
    getent passwd "$name" >/dev/null 2>&1 && return 1
    valid=$(date '+%Y-%m-%d' -d "+${days} days") || return 1
    hash=$(openssl passwd -6 "$pass" 2>/dev/null)
    [[ -z "$hash" ]] && hash=$(openssl passwd -1 "$pass" 2>/dev/null)
    [[ -z "$hash" ]] && return 1
    useradd -M -s /bin/false -e "$valid" -c "${limit},${disp}" -p "$hash" "$name" >/dev/null 2>&1 || return 1
    getent passwd "$name" >/dev/null 2>&1 || return 1
    escribir_userdir "$name" "$disp" "$limit" "$valid"
    registrar_usuario "$name"
    c_valid="$valid"
    c_datexp=$(date '+%d/%m/%Y' -d "+${days} days")
    return 0
}

# TOKEN / HWID / restore: usa add_new_user si existe en el sistema; si no, crea local
crear_cuenta_ext() {   # usuario pass dias limite nombre_visible
    local name="$1" pass="$2" days="$3" limit="$4" disp="$5" newfile="n" ovpnauth="n"
    getent passwd "$name" >/dev/null 2>&1 && return 1
    if declare -F add_new_user >/dev/null 2>&1 || command -v add_new_user >/dev/null 2>&1; then
        if dpkg --get-selections 2>/dev/null | grep -qw openvpn && [[ -e /etc/openvpn/openvpn-status.log ]]; then
            newfile="s"; ovpnauth="s"
        fi
        add_new_user "$name" "$pass" "$(( 10#$days + 1 ))" "$limit" "$newfile" "$ovpnauth" "$disp" </dev/null &>/dev/null
        getent passwd "$name" >/dev/null 2>&1 || return 1
        c_valid=$(date '+%Y-%m-%d' -d "+${days} days")
        c_datexp=$(date '+%d/%m/%Y' -d "+${days} days")
        escribir_userdir "$name" "$disp" "$limit" "$c_valid"
        registrar_usuario "$name"
        return 0
    fi
    crear_cuenta "$name" "$pass" "$days" "$limit" "$disp"
}

# Lee los datos de una cuenta -> u_disp u_sen u_limit u_dias
datos_usuario() {   # usuario [contador]
    local u="$1" cont="${2:-1}" exp exp_s hoy linea cap
    exp=$(LC_ALL=C chage -l "$u" 2>/dev/null | awk -F': ' '/Account expires/ {print $2}')
    hoy=$(date +%s)
    if [[ -z "$exp" || "$exp" == "never" ]]; then
        u_dias="Null"
    else
        exp_s=$(date +%s -d "$exp" 2>/dev/null)
        if [[ -z "$exp_s" ]]; then u_dias="Null"
        elif (( hoy > exp_s )); then u_dias="CADUCADO"
        else u_dias=$(( (exp_s - hoy) / 86400 ))
        fi
    fi
    u_disp="$u"; u_sen="Null"; u_limit="Null"
    if [[ -e "$dir_user/$u" ]]; then
        u_sen=$(awk '/^senha/ {print $2}' "$dir_user/$u")
        u_limit=$(awk '/^limite/ {print $2}' "$dir_user/$u")
        if [[ "$u_limit" == @(HWID|TOKEN) ]]; then u_disp="$u_sen"; u_sen="$u"; fi
    else
        linea="$(getent passwd "$u")"
        cap=""
        if [[ "$linea" =~ ,([^:]+): ]]; then cap="${BASH_REMATCH[1]}"; fi
        u_sen="${cap:-Null}"
        u_limit=$(awk -F: '{split($5,a,","); print a[1]}' <<< "$linea")
        if [[ "$u_limit" == @(HWID|TOKEN) ]]; then
            u_disp="${cap:-TK0${cont}}"
            u_sen="$u"
        fi
    fi
    [[ -z "$u_limit" ]] && u_limit="Null"
    [[ -z "$u_sen" ]] && u_sen="Null"
    return 0
}

# Datos del servidor para mostrar junto a una cuenta nueva (SlowDNS opcional)
core_datos_servidor() {
    R_IP="$(ip_srv)"
    R_NS=""; R_PUB=""; R_PROTO=""
    [[ -e "$DATA_DIR/slow/dnsi/domain_ns" ]] && R_NS="$(cat "$DATA_DIR/slow/dnsi/domain_ns")"
    [[ -e "$DATA_DIR/slow/dnsi/server.pub" ]] && R_PUB="$(cat "$DATA_DIR/slow/dnsi/server.pub")"
    if [[ -e "$DATA_DIR/slow/dnsi/protc" && -e "$DATA_DIR/slow/dnsi/puerto" ]]; then
        R_PROTO="$(cat "$DATA_DIR/slow/dnsi/protc") -> $(cat "$DATA_DIR/slow/dnsi/puerto")"
    fi
}

# Rellena el resultado comun de una cuenta recien creada/renovada
_resultado_cuenta() {   # tipo usuario etiqueta secreto expira limite dias
    R_TIPO="$1"; R_USER="$2"; R_ETQ="$3"; R_SECRET="$4"; R_EXPIRA="$5"; R_LIMITE="$6"; R_DIAS="$7"
    R_CRED="$(cred_txt "$R_CRED_NUEVO")"
    core_datos_servidor
}

# --------------------------- creacion de cuentas ----------------------
core_crear_ssh() {   # nombre clave dias limite
    local name="$1" pass="$2" days="$3" limit="$4"
    R_ESTADO=ok; R_MSG=""; R_USER="$name"
    nombre_valido "$name" || { R_ESTADO=invalido; R_MSG="nombre"; return 1; }
    pass_valida "$pass"   || { R_ESTADO=invalido; R_MSG="clave"; return 1; }
    en_rango "$days" 1 3650 || { R_ESTADO=invalido; R_MSG="dias"; return 1; }
    en_rango "$limit" 1 999 || { R_ESTADO=invalido; R_MSG="limite"; return 1; }
    getent passwd "$name" >/dev/null 2>&1 && { R_ESTADO=existe; return 1; }
    R_CRED_NUEVO="$(consumir_credito)" || { R_ESTADO=sin_creditos; return 1; }
    if ! crear_cuenta "$name" "$pass" "$days" "$limit"; then
        devolver_credito; R_ESTADO=error; return 1
    fi
    _resultado_cuenta SSH "$name" "PASSWD" "$pass" "$c_datexp" "$limit" "$days"
}

core_crear_token() {   # nombre token dias
    local nombre="$1" token="$2" dias="${3:-30}"
    R_ESTADO=ok; R_MSG=""; R_USER="$token"
    nombre_valido "$nombre" || { R_ESTADO=invalido; R_MSG="nombre"; return 1; }
    nombre_valido "$token"  || { R_ESTADO=invalido; R_MSG="token"; return 1; }
    en_rango "$dias" 1 3650 || { R_ESTADO=invalido; R_MSG="dias"; return 1; }
    getent passwd "$token" >/dev/null 2>&1 && { R_ESTADO=existe; return 1; }
    R_CRED_NUEVO="$(consumir_credito)" || { R_ESTADO=sin_creditos; return 1; }
    if ! crear_cuenta_ext "$token" "$(pass_token)" "$dias" "TOKEN" "$nombre"; then
        devolver_credito; R_ESTADO=error; return 1
    fi
    _resultado_cuenta TOKEN "$nombre" "TOKEN" "$token" "$c_datexp" "" "$dias"
}

core_crear_hwid() {   # nombre hwid dias
    local nombre="$1" hwid="$2" dias="${3:-30}"
    R_ESTADO=ok; R_MSG=""; R_USER="$hwid"
    nombre_valido "$nombre" || { R_ESTADO=invalido; R_MSG="nombre"; return 1; }
    nombre_valido "$hwid"   || { R_ESTADO=invalido; R_MSG="hwid"; return 1; }
    en_rango "$dias" 1 3650 || { R_ESTADO=invalido; R_MSG="dias"; return 1; }
    getent passwd "$hwid" >/dev/null 2>&1 && { R_ESTADO=existe; return 1; }
    R_CRED_NUEVO="$(consumir_credito)" || { R_ESTADO=sin_creditos; return 1; }
    if ! crear_cuenta_ext "$hwid" "$hwid" "$dias" "HWID" "$nombre"; then
        devolver_credito; R_ESTADO=error; return 1
    fi
    _resultado_cuenta HWID "$nombre" "HWID" "$hwid" "$c_datexp" "" "$dias"
}

# --------------------------------- demos ------------------------------
core_crear_demo() {   # [token]
    local tok="$1" ahora usados name pass limit disp venc
    DEMO_MAX="${DEMO_MAX:-3}"; DEMO_DIAS="${DEMO_DIAS:-2}"
    R_ESTADO=ok; R_MSG=""
    ahora=$(date +%s)
    (
        flock 9
        awk -F'|' -v n="$ahora" 'NF==3 && $3>n' "$DEMOS" > "${DEMOS}.tmp" && cat "${DEMOS}.tmp" > "$DEMOS"
        rm -f "${DEMOS}.tmp"
    ) 9>"$LOCK"
    usados=$(awk -F'|' -v id="$CTX_UID" '$1==id' "$DEMOS" | wc -l)
    R_MAX="$DEMO_MAX"
    (( usados >= DEMO_MAX )) && { R_ESTADO=max_demos; return 1; }
    if [[ -n "$tok" ]]; then
        nombre_valido "$tok" || { R_ESTADO=invalido; R_MSG="token"; return 1; }
        name="$tok"; pass="$(pass_token)"; limit="TOKEN"; disp="$tok"
    else
        name="demo-$(echo "$RANDOM$(date +%s%N)" | md5sum | head -c8)"
        pass="$(gen_pass)"; limit=1; disp="$pass"
    fi
    R_USER="$name"
    if ! crear_cuenta "$name" "$pass" "$DEMO_DIAS" "$limit" "$disp"; then
        R_ESTADO=existe; return 1
    fi
    venc=$(date -d "+${DEMO_DIAS} days" +%s)
    ( flock 9; echo "${CTX_UID}|${name}|${venc}" >> "$DEMOS" ) 9>"$LOCK"
    if command -v at >/dev/null 2>&1; then
        at now + ${DEMO_DIAS} days >/dev/null 2>&1 <<EOF
pkill -KILL -u '${name}' >/dev/null 2>&1
userdel --force '${name}' >/dev/null 2>&1
rm -f '${dir_user}/${name}'
sed -i '/^[0-9]*|${name}\$/d' '${REG}'
sed -i '/^[0-9]*|${name}|/d' '${DEMOS}'
if [ -f '${EJE_DIR}/uskill' ]; then echo \$(( \$(cat '${EJE_DIR}/uskill') + 1 )) > '${EJE_DIR}/uskill'; fi
EOF
    fi
    R_CRED_NUEVO="$(cred_actual "$CTX_UID")"
    R_RESTANTES=$(( DEMO_MAX - usados - 1 ))
    if [[ -n "$tok" ]]; then
        _resultado_cuenta DEMO "$name" "TOKEN" "$name" "$c_datexp" "" "$DEMO_DIAS"
    else
        _resultado_cuenta DEMO "$name" "CLAVE" "$pass" "$c_datexp" "1" "$DEMO_DIAS"
    fi
}

# -------------------------------- renovar -----------------------------
# modo: ""  reinicia a N dias | M  suma N dias | Q  resta N dias
_renovar_sistema() {   # usuario dias modo   -> 0 ok | 1 no existe | 2 dias | 3 error
    local _user="$1" _time="$2" _ruta="$3" exp exp_s hoy dias_restantes datexp localtiempo valid limite usr_var
    [[ -z "$_user" ]] && return 1
    puede_gestionar "$_user" || return 1
    exp=$(LC_ALL=C chage -l "$_user" 2>/dev/null | awk -F': ' '/Account expires/ {print $2}')
    hoy=$(date +%s)
    if [[ -z "$exp" || "$exp" == "never" ]]; then
        dias_restantes=-1
    else
        exp_s=$(date -d "$exp" +%s 2>/dev/null) || return 3
        dias_restantes=$(( (exp_s - hoy) / 86400 ))
    fi
    case "$_ruta" in
        M) (( dias_restantes >= 0 )) && _time=$(( dias_restantes + 10#$_time )) ;;
        Q)
            if (( dias_restantes < 0 || 10#$_time > dias_restantes )); then return 2; fi
            _time=$(( dias_restantes - 10#$_time ))
            ;;
    esac
    [[ "$(passwd --status "$_user" 2>/dev/null | cut -d' ' -f2)" == "L" ]] && usermod -U "$_user"
    limite=$(getent passwd "$_user" | awk -F: '{split($5,a,","); print a[1]}')
    [[ -z "$limite" ]] && limite="null"
    datexp=$(date '+%d/%m/%Y' -d "+${_time} days")
    localtiempo=$(( 10#$_time + 1 ))
    valid=$(date '+%Y-%m-%d' -d "+${localtiempo} days")
    if chage -E "$valid" "$_user"; then
        chage -d "$valid" -M "$localtiempo" "$_user"
        if [[ -e "$dir_user/$_user" ]]; then
            usr_var=$(grep -v '^data' "$dir_user/$_user")
            { echo "$usr_var"; echo "data: $valid"; } > "$dir_user/$_user"
        fi
        pkill -u "$_user" 2>/dev/null
        r_usr="$_user"; r_datexp="$datexp"; r_limit="$limite"; r_days="$_time"
        return 0
    fi
    return 3
}

core_renovar() {   # modo usuario dias
    local modo="$1" name="$2" dias="$3" rc
    R_ESTADO=ok; R_USER="$name"; R_MODO="$modo"
    nombre_seguro "$name" && en_rango "$dias" 1 3650 || { R_ESTADO=invalido; return 1; }
    puede_gestionar "$name" || { R_ESTADO=no_encontrado; return 1; }
    if [[ "$modo" != "Q" ]]; then
        R_CRED_NUEVO="$(consumir_credito)" || { R_ESTADO=sin_creditos; return 1; }
    else
        R_CRED_NUEVO="$(cred_actual "$CTX_UID")"
    fi
    _renovar_sistema "$name" "$dias" "$modo"; rc=$?
    if (( rc != 0 )); then
        [[ "$modo" != "Q" ]] && devolver_credito
        case $rc in
            1) R_ESTADO=no_encontrado;;
            2) R_ESTADO=dias;;
            *) R_ESTADO=error;;
        esac
        return 1
    fi
    R_TIPO=RENOVADA; R_USER="$r_usr"; R_EXPIRA="$r_datexp"; R_LIMITE="$r_limit"; R_DIAS="$r_days"
    R_CRED="$(cred_txt "$R_CRED_NUEVO")"
    core_datos_servidor
}

# --------------------------------- borrar -----------------------------
core_borrar() {   # usuario
    local u="$1"
    R_ESTADO=ok; R_USER="$u"
    puede_gestionar "$u" || { R_ESTADO=no_encontrado; return 1; }
    pkill -KILL -u "$u" 2>/dev/null
    userdel --force "$u" >/dev/null 2>&1
    if getent passwd "$u" >/dev/null 2>&1; then R_ESTADO=error; return 1; fi
    rm -f "$dir_user/$u"
    quitar_registro "$u"
    return 0
}

# ------------------------- consultas / listados ------------------------
core_cuenta_info() {   # usuario -> R_USER(visible) R_ACCOUNT R_SECRET R_LIMITE R_DIAS_TXT
    R_ESTADO=ok
    puede_gestionar "$1" || { R_ESTADO=no_encontrado; return 1; }
    datos_usuario "$1" 1
    R_ACCOUNT="$1"; R_USER="$u_disp"; R_SECRET="$u_sen"; R_LIMITE="$u_limit"; R_DIAS_TXT="$u_dias"
}

# scope: all (solo super) | mine   -> LST_USER LST_DISP LST_SEN LST_LIMIT LST_DIAS
core_listar() {
    local scope="$1" u cont=1
    LST_USER=(); LST_DISP=(); LST_SEN=(); LST_LIMIT=(); LST_DIAS=()
    R_ESTADO=ok
    local -a src=()
    if [[ "$scope" == "all" ]]; then
        [[ "$CRED" == "X" ]] || { R_ESTADO=permisos; return 1; }
        mapfile -t src < <(lista_cuentas_bot)
    else
        mapfile -t src < <(awk -F'|' -v a="$CTX_UID" '$1==a {print $2}' "$REG" 2>/dev/null | sort -u)
    fi
    for u in "${src[@]}"; do
        [[ -z "$u" ]] && continue
        getent passwd "$u" >/dev/null 2>&1 || continue
        datos_usuario "$u" "$cont"
        LST_USER+=("$u"); LST_DISP+=("$u_disp"); LST_SEN+=("$u_sen")
        LST_LIMIT+=("$u_limit"); LST_DIAS+=("$u_dias")
        cont=$(( cont + 1 ))
    done
    return 0
}
