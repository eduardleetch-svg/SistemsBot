#!/bin/bash
# =====================================================================
#  core/creditos.sh - administradores y creditos (logica pura)
#  Archivo: $LIB  con lineas  id|creditos   (X = ilimitado)
# =====================================================================

cred_actual()  { awk -F'|' -v id="$1" '$1==id {print $2; exit}' "$LIB" 2>/dev/null; }
existe_admin() { awk -F'|' -v id="$1" '$1==id {f=1} END{exit !f}' "$LIB" 2>/dev/null; }

es_dueno() {
    local o="${OWNER_ID:-$(head -n1 "$LIB" 2>/dev/null | cut -d'|' -f1)}"
    [[ -n "$1" && "$1" == "$o" ]]
}

cred_txt() { if [[ "$1" == "X" || "$1" == "9999" ]]; then echo "ILIMITADOS"; else echo "$1"; fi; }

# Fija el credito de un ID (crea la linea si no existe)
set_cred() {   # id valor
    (
        flock 9
        if existe_admin "$1"; then
            sed -i "s/^$1|.*/$1|$2/" "$LIB"
        else
            echo "$1|$2" >> "$LIB"
        fi
    ) 9>"$LOCK"
}

# Suma (o devuelve) creditos; no toca a los ilimitados
sumar_cred() {   # id cantidad
    (
        flock 9
        r="$(cred_actual "$1")"
        [[ "$r" == "X" ]] && exit 0
        [[ "$r" =~ ^[0-9]+$ ]] || r=0
        nuevo=$(( 10#$r + 10#$2 ))
        if existe_admin "$1"; then
            sed -i "s/^$1|.*/$1|${nuevo}/" "$LIB"
        else
            echo "$1|${nuevo}" >> "$LIB"
        fi
    ) 9>"$LOCK"
}

# Descuenta 1 credito ANTES de actuar. Imprime el saldo nuevo (o X). Falla si no hay.
consumir_credito() {
    (
        flock 9
        r="$(cred_actual "$CTX_UID")"
        [[ "$r" == "X" ]] && { echo "X"; exit 0; }
        [[ "$r" =~ ^[0-9]+$ ]] && (( 10#$r > 0 )) || exit 1
        nuevo=$(( 10#$r - 1 ))
        sed -i "s/^${CTX_UID}|.*/${CTX_UID}|${nuevo}/" "$LIB"
        echo "$nuevo"
    ) 9>"$LOCK"
}

devolver_credito() { sumar_cred "$CTX_UID" 1; }

# ----------------------- operaciones de administracion -----------------
# Todas dejan R_ESTADO: ok | invalido | permisos | existe | no_encontrado | dueno | ilimitado

core_admin_agregar() {   # id [creditos|X]
    local idn="$1" cr="${2:-0}"
    R_ESTADO=ok
    es_dueno "$CTX_UID" || { R_ESTADO=permisos; return 1; }
    id_valido "$idn" && [[ "$cr" =~ ^([0-9]+|X)$ ]] || { R_ESTADO=invalido; return 1; }
    existe_admin "$idn" && { R_ESTADO=existe; return 1; }
    set_cred "$idn" "$cr"
    R_ID="$idn"; R_CRED="$(cred_txt "$cr")"
    return 0
}

core_admin_creditos() {   # id cantidad  (suma)
    local idn="$1" n="$2" actual
    R_ESTADO=ok
    es_dueno "$CTX_UID" || { R_ESTADO=permisos; return 1; }
    id_valido "$idn" && en_rango "$n" 1 100000 || { R_ESTADO=invalido; return 1; }
    actual="$(cred_actual "$idn")"
    [[ "$actual" == "X" ]] && { R_ESTADO=ilimitado; return 1; }
    sumar_cred "$idn" "$n"
    R_ID="$idn"; R_SUMADOS="$n"; R_CRED="$(cred_actual "$idn")"
    return 0
}

core_admin_quitar() {   # id
    local idn="$1"
    R_ESTADO=ok
    es_dueno "$CTX_UID" || { R_ESTADO=permisos; return 1; }
    id_valido "$idn" || { R_ESTADO=invalido; return 1; }
    es_dueno "$idn" && { R_ESTADO=dueno; return 1; }
    existe_admin "$idn" || { R_ESTADO=no_encontrado; return 1; }
    R_ID="$idn"; R_CRED="$(cred_txt "$(cred_actual "$idn")")"
    (
        flock 9
        sed -i "/^${idn}|/d" "$LIB"
    ) 9>"$LOCK"
    return 0
}

# Llena ADM_ID[] y ADM_CRED[] con todos los autorizados (menos el dueno)
core_admin_listar() {
    ADM_ID=(); ADM_CRED=()
    local i c
    while IFS='|' read -r i c _; do
        [[ -z "$i" ]] && continue
        es_dueno "$i" && continue
        ADM_ID+=("$i"); ADM_CRED+=("$(cred_txt "$c")")
    done < "$LIB"
}

# Activacion con usuario y clave de ./bottokens  (/access usuario clave)
core_activar_acceso() {   # usuario clave
    local base="${SB_BOTTOKENS:-./bottokens}"
    R_ESTADO=ok
    if existe_admin "$CTX_UID"; then R_ESTADO=existe; return 1; fi
    [[ -n "$1" && -n "$2" && -f "$base" ]] || { R_ESTADO=invalido; return 1; }
    [[ "$(head -n1 "$base" | awk '{print $1}')" == "$1:$2" ]] || { R_ESTADO=invalido; return 1; }
    set_cred "$CTX_UID" "X"
    R_NUM="$(wc -l < "$LIB")"
    return 0
}
