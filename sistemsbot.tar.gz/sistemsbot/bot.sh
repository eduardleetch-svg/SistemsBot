#!/bin/bash
# =====================================================================
#  sistemsbot - arranque.   Uso: bot.sh [TOKEN]
# =====================================================================
SB_SELF="$(readlink -f "${BASH_SOURCE[0]}")"
SB_HOME="${SB_HOME:-$(dirname "$SB_SELF")}"
export SB_HOME

source "$SB_HOME/lib/boot.sh"
[[ -n "$1" ]] && BOT_TOKEN="$1"
[[ -n "$BOT_TOKEN" ]] || { echo "Falta BOT_TOKEN en $SB_CONF (o pásalo como argumento)"; exit 1; }
[[ -n "$OWNER_ID" ]] && ! [[ "$OWNER_ID" =~ ^[0-9]+$ ]] && { echo "OWNER_ID inválido"; exit 1; }

init_paths

# ShellBot solo recibe updates
source "$SB_HOME/lib/ShellBot.sh"
set +f      # ShellBot desactiva los comodines; las vistas los usan
ShellBot.init --token "$BOT_TOKEN" >/dev/null 2>&1
me="$(tg_api getMe)"
tg_check "$me" getMe || { echo "Token rechazado por Telegram"; exit 1; }
echo "sistemsbot iniciado: $(grep -o '"username":"[^"]*"' <<< "$me" | head -n1) | tema: $THEME_ACTIVE"
sb_log "start theme=$THEME_ACTIVE"

# Un usuario a la vez (flock por usuario); usuarios distintos en paralelo
run_update() {
    local uid="${callback_query_from_id[$id]:-${message_from_id[$id]:-${message_chat_id[$id]}}}"
    [[ "$uid" =~ ^[0-9]+$ ]] || return 0
    (
        flock -w 120 9 || exit 0
        dispatch_update
    ) 9>"$LOCKDIR/u$uid.lock"
}

# Limpieza periodica de asistentes caducados
flow_gc() { find "$FLOW_DIR" -type f -mmin +30 -delete 2>/dev/null; }

n=0
while :; do
    ShellBot.getUpdates --limit 100 --offset "$(ShellBot.OffsetNext)" --timeout 30 \
        --allowed_updates '["message","callback_query"]'
    for id in $(ShellBot.ListUpdates); do
        run_update &
    done
    n=$((n+1)); (( n % 20 == 0 )) && flow_gc
    # evita acumular procesos si hay mucha carga
    while (( $(jobs -rp | wc -l) > 40 )); do sleep 0.2; done
done
