#!/bin/bash
# =====================================================================
#  views/common.sh - piezas comunes de presentacion
#  Las vistas NO calculan nada: solo leen R_* / LST_* y dibujan.
#  Todo el aspecto (iconos, separadores, etiquetas, animacion) viene del
#  tema activo (themes/*.sh) y los textos de lang/*.sh
# =====================================================================

B=""            # buffer del mensaje en construccion
L_NOTE=""       # aviso de una sola vez (se muestra en el siguiente menu)

ui_begin() { B=""; KB_ROWS=(); }

b_head() { B+="${T_TOP}${NL}<b>$(esc "$1")</b>${NL}${T_TOP}${NL}"; }
b_sep()  { B+="${T_SEP}${NL}"; }
b_raw()  { B+="$1${NL}"; }                              # HTML ya escapado
b_txt()  { B+="$(esc "$1")${NL}"; }                     # texto plano
b_kv()   { B+="$1 $2: <code>$(esc "$3")</code>${NL}"; } # icono etiqueta valor
b_note() { if [[ -n "$L_NOTE" ]]; then B+="$(esc "$L_NOTE")${NL}"; L_NOTE=""; fi; }

# Muestra el texto: edita el mensaje actual o envia uno nuevo
ui_show() {   # texto [teclado_json]
    if [[ -n "$UI_MID" ]]; then
        tg_edit "$CTX_CHAT" "$UI_MID" "$1" "$2"
    else
        tg_send "$CTX_CHAT" "$1" "$2"
    fi
    UI_MID="$TG_LAST_MID"
}

ui_flush() { ui_show "$B" "$(kb_json)"; }

# Animacion de "cargando" definida por el tema (T_ANIM, T_ANIM_DELAY)
ui_anim() {   # titulo
    [[ "${ANIMATIONS:-on}" == "on" ]] || return 0
    local f
    for f in "${T_ANIM[@]}"; do
        ui_begin; b_head "$1"; b_raw "$f"; ui_flush
        sleep "${T_ANIM_DELAY:-0.3}"
    done
}

# ------------------------- botones reutilizables ----------------------
kb_home() { kb_row "$B_HOME" "m:home"; }
kb_nav()  { kb_row "$B_BACK" "$1" "$B_HOME" "m:home"; }

kb_pager() {   # callback_base pagina total   (base: "usr:list:auto")  sufijo opcional
    local base="$1" pg="$2" total="$3" suf="$4"
    (( total <= 1 )) && return 0
    local -a r=()
    (( pg > 1 ))      && r+=("$B_PREV" "${base}:$((pg-1))${suf}")
    r+=("${pg}/${total}" "m:noop")
    (( pg < total ))  && r+=("$B_NEXT" "${base}:$((pg+1))${suf}")
    kb_row "${r[@]}"
}

# ------------------------------ menus ---------------------------------
MENU_ITEMS=()
menu_btn() { MENU_ITEMS+=("$1|$2|$3|$4|$5|$6"); }   # menu|nivel|fila|etiqueta_var|callback|condicion

rank_of()   { case "$1" in dueno) echo 3;; super) echo 2;; reseller) echo 1;; *) echo 0;; esac; }
user_rank() {
    if [[ "$CRED" == "X" ]] && es_dueno "$CTX_UID"; then echo 3
    elif [[ "$CRED" == "X" ]]; then echo 2
    elif [[ -n "$CRED" ]]; then echo 1
    else echo 0; fi
}

kb_menu() {   # nombre_del_menu
    local name="$1" rank it m niv fila lab cb cond lastfila=""
    local -a row=()
    rank="$(user_rank)"
    for it in "${MENU_ITEMS[@]}"; do
        IFS='|' read -r m niv fila lab cb cond <<< "$it"
        [[ "$m" == "$name" ]] || continue
        (( $(rank_of "$niv") <= rank )) || continue
        if [[ -n "$cond" ]] && ! "$cond"; then continue; fi
        if [[ "$fila" != "$lastfila" && ${#row[@]} -gt 0 ]]; then kb_row "${row[@]}"; row=(); fi
        lastfila="$fila"
        row+=("${!lab}" "$cb")
    done
    (( ${#row[@]} > 0 )) && kb_row "${row[@]}"
}
