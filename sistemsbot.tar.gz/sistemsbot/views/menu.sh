#!/bin/bash
# =====================================================================
#  views/menu.sh - pantallas: menu, bloqueo, errores generales, temas
# =====================================================================

vista_menu() {
    local role
    ui_begin
    b_head "$L_APP"
    b_note
    case "$(user_rank)" in
        3) role="$L_ROLE_OWNER";;
        2) role="$L_ROLE_SUPER";;
        *) role="$L_ROLE_RESELLER";;
    esac
    b_kv "$I_USER" "$L_ROLE" "$role"
    b_kv "$I_CRED" "$L_CREDITS" "$(cred_txt "$CRED")"
    b_kv "$I_IP" "IP" "$(ip_srv)"
    b_sep
    b_txt "$L_MENU_HINT"
    kb_menu principal
    ui_flush
}

vista_menu_mas() {
    ui_begin
    b_head "$L_MORE_T"
    b_txt "$L_MORE_HINT"
    kb_menu mas
    kb_nav "m:home"
    ui_flush
}

vista_bloqueado() {
    ui_begin
    b_head "$L_BLOCKED_T"
    b_txt "$L_BLOCKED_1"
    b_kv "$I_KEY" "ID" "$CTX_UID"
    b_sep
    b_txt "$L_BLOCKED_2"
    ui_flush
}

vista_sin_permiso() {
    ui_begin
    b_head "$L_ERR_T"
    b_txt "$L_ERR_NOPERM"
    kb_home
    ui_flush
}

vista_desconocido() {
    ui_begin
    b_head "$L_ERR_T"
    b_txt "$L_ERR_UNKNOWN"
    kb_home
    ui_flush
}

vista_temas() {
    local f t
    ui_begin
    b_head "$L_THEME_T"
    b_txt "$L_THEME_HINT"
    for f in "$SB_HOME"/themes/*.sh; do
        t="$(basename "$f" .sh)"
        if [[ "$t" == "$THEME_ACTIVE" ]]; then
            kb_row "✅ $(THEME_LABEL_OF "$t")" "m:tema:$t"
        else
            kb_row "$(THEME_LABEL_OF "$t")" "m:tema:$t"
        fi
    done
    kb_nav "m:home"
    ui_flush
}

# Lee T_NAME de un tema sin cargarlo en el contexto actual
THEME_LABEL_OF() { ( source "$SB_HOME/themes/$1.sh"; printf '%s' "$T_NAME" ); }

vista_error() {   # usa R_ESTADO R_MSG R_USER
    ui_begin
    b_head "$L_ERR_T"
    case "$R_ESTADO" in
        invalido)     b_txt "$L_ERR_INVALID"; [[ -n "$R_MSG" ]] && b_kv "$I_ERR" "?" "$R_MSG";;
        existe)       b_txt "$L_ERR_EXISTS"; b_kv "$I_USER" "$L_USER" "$R_USER";;
        sin_creditos) b_txt "$L_ERR_NOCRED";;
        no_encontrado) b_txt "$L_ERR_NOTFOUND"; [[ -n "$R_USER" ]] && b_kv "$I_USER" "$L_USER" "$R_USER";;
        dias)         b_txt "$L_ERR_DAYS";;
        max_demos)    b_txt "$L_ERR_DEMOMAX"; b_kv "$I_WAIT" "$L_MAX" "$R_MAX";;
        permisos)     b_txt "$L_ERR_NOPERM";;
        dueno)        b_txt "$L_ERR_OWNER";;
        ilimitado)    b_txt "$L_ERR_UNLIMITED";;
        *)            b_txt "$L_ERR_GENERIC"; [[ -n "$R_MSG" ]] && b_kv "$I_ERR" "?" "$R_MSG";;
    esac
    kb_home
    ui_flush
}
