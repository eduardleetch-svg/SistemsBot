#!/bin/bash
# =====================================================================
#  views/admin.sh - pantallas de administracion de resellers (dueno)
# =====================================================================

vista_admin_menu() {
    ui_begin
    b_head "$L_ADM_T"
    b_note
    b_txt "$L_ADM_HINT"
    kb_row "$B_ADM_ADD" "new:admin" "$B_ADM_CRED" "adm:pick:cr"
    kb_row "$B_ADM_KILL" "adm:pick:kill" "$B_ADM_LIST" "adm:list"
    kb_nav "m:mas"
    ui_flush
}

vista_admin_lista() {   # usa ADM_ID ADM_CRED
    local i
    ui_begin
    b_head "$L_ADM_LIST_T"
    if (( ${#ADM_ID[@]} == 0 )); then
        b_txt "$L_ADM_NONE"
    else
        for (( i = 0; i < ${#ADM_ID[@]}; i++ )); do
            b_kv "$I_ADMIN" "${ADM_ID[$i]}" "${ADM_CRED[$i]} ${L_CRED_WORD}"
        done
    fi
    kb_nav "adm:menu"
    ui_flush
}

# Elegir un reseller con botones. modo: cr (sumar creditos) | kill (quitar)
vista_admin_elegir() {   # modo
    local i modo="$1" title
    [[ "$modo" == "kill" ]] && title="$L_ADM_KILL_T" || title="$L_ADM_CRED_T"
    ui_begin
    b_head "$title"
    if (( ${#ADM_ID[@]} == 0 )); then
        b_txt "$L_ADM_NONE"
    else
        b_txt "$L_ADM_PICK"
        for (( i = 0; i < ${#ADM_ID[@]} && i < 40; i++ )); do
            kb_row "${I_ADMIN} ${ADM_ID[$i]} · ${ADM_CRED[$i]}" "adm:${modo}:${ADM_ID[$i]}"
        done
    fi
    kb_nav "adm:menu"
    ui_flush
}

vista_admin_confirmar_quitar() {   # id
    ui_begin
    b_head "$L_ADM_KILL_T"
    b_txt "$L_ADM_KILL_ASK"
    b_kv "$I_ADMIN" "ID" "$1"
    kb_row "$B_DEL_YES" "adm:killok:$1" "$B_CANCEL" "adm:menu"
    ui_flush
}

vista_admin_resultado() {   # tipo: agregado | creditos | quitado
    ui_begin
    case "$1" in
        agregado) b_head "$L_ADM_ADDED_T";;
        creditos) b_head "$L_ADM_CREDITED_T";;
        quitado)  b_head "$L_ADM_REMOVED_T";;
    esac
    b_kv "$I_ADMIN" "ID" "$R_ID"
    b_kv "$I_CRED" "$L_CREDITS" "$R_CRED"
    [[ "$1" == "creditos" ]] && b_kv "$I_OK" "$L_ADDED" "$R_SUMADOS"
    kb_nav "adm:menu"
    ui_flush
}

# Mensaje al dueno cuando un reseller crea/renueva (sin claves)
vista_notificar_dueno() {   # accion usuario dias
    [[ -e "$EJE_DIR/notyadd" ]] || return 0
    local dueno="${OWNER_ID:-$(head -n1 "$LIB" | cut -d'|' -f1)}"
    [[ -z "$dueno" || "$dueno" == "$CTX_UID" ]] && return 0
    local quien="ID ${CTX_UID}"
    [[ -n "$CTX_USERNAME" ]] && quien="@${CTX_USERNAME}"
    tg_send "$dueno" "${T_SEP}${NL}$(esc "$quien") ${1} <code>$(esc "$2")</code> · ${3} ${L_DAYS}${NL}${T_SEP}"
}

# Mensaje al afectado cuando el dueno le cambia el acceso
vista_avisar_admin() {   # id titulo
    tg_send "$1" "${T_TOP}${NL}<b>$(esc "$2")</b>${NL}${T_TOP}${NL}$(esc "$L_ADM_NOTICE")"
}
