#!/bin/bash
# =====================================================================
#  views/prompts.sh - pantallas de los asistentes (una funcion vp_<flujo>)
#  Solo dibujan el paso actual; la logica esta en flows/<flujo>.sh
# =====================================================================

vp_begin() {   # titulo
    ui_begin
    b_head "$1"
    [[ -n "$FLOW_ERR" ]] && b_raw "${I_ERR} $(esc "$FLOW_ERR")"
}

vp_end() { kb_row "$B_CANCEL" "fl:cancel"; ui_flush; }

kb_opts() {   # flujo paso "etiqueta" valor ["etiqueta" valor ...]  -> una fila
    local f="$1" s="$2"; shift 2
    local -a r=()
    while (( $# >= 2 )); do r+=("$1" "fl:${f}:${s}:$2"); shift 2; done
    kb_row "${r[@]}"
}

kb_days() {   # flujo paso
    kb_opts "$1" "$2" "7${L_D}" 7 "15${L_D}" 15 "30${L_D}" 30
    kb_opts "$1" "$2" "60${L_D}" 60 "90${L_D}" 90 "180${L_D}" 180
}

kb_confirm() { kb_row "$B_CONFIRM" "fl:$1:confirmar:ok"; }

# ------------------------------- SSH ----------------------------------
vp_agregar() {
    vp_begin "$L_P_ADD"
    case "$1" in
        nombre)
            b_txt "$L_ASK_NAME"; b_txt "$L_HINT_NAME";;
        clave)
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_txt "$L_ASK_PASS"; b_txt "$L_HINT_PASS"
            kb_row "$B_FAST" "fl:agregar:clave:__fast"
            kb_row "$B_GEN" "fl:agregar:clave:__gen";;
        dias)
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_txt "$L_ASK_DAYS"; kb_days agregar dias;;
        limite)
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_kv "$I_CAL" "$L_DAYS" "$(flow_get dias)"
            b_txt "$L_ASK_LIMIT"
            kb_opts agregar limite "1" 1 "2" 2 "3" 3 "5" 5 "10" 10;;
        confirmar)
            b_txt "$L_CONFIRM_ASK"
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_kv "$I_KEY" "$L_PASS" "$(flow_get clave)"
            b_kv "$I_CAL" "$L_DAYS" "$(flow_get dias)"
            b_kv "$I_LIM" "$L_LIMIT" "$(flow_get limite)"
            kb_confirm agregar;;
    esac
    vp_end
}

# ---------------------------- TOKEN / HWID ----------------------------
vp_token() {
    vp_begin "$L_P_TOKEN"
    case "$1" in
        nombre) b_txt "$L_ASK_NAME_CLIENT"; b_txt "$L_HINT_NAME";;
        token)
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_txt "$L_ASK_TOKEN"; b_txt "$L_HINT_NAME";;
        dias)
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_txt "$L_ASK_DAYS"; kb_days token dias;;
        confirmar)
            b_txt "$L_CONFIRM_ASK"
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_kv "$I_KEY" "TOKEN" "$(flow_get token)"
            b_kv "$I_CAL" "$L_DAYS" "$(flow_get dias)"
            kb_confirm token;;
    esac
    vp_end
}

vp_hwid() {
    vp_begin "$L_P_HWID"
    case "$1" in
        nombre) b_txt "$L_ASK_NAME_CLIENT"; b_txt "$L_HINT_NAME";;
        hwid)
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_txt "$L_ASK_HWID"; b_txt "$L_HINT_NAME";;
        dias)
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_txt "$L_ASK_DAYS"; kb_days hwid dias;;
        confirmar)
            b_txt "$L_CONFIRM_ASK"
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_kv "$I_KEY" "HWID" "$(flow_get hwid)"
            b_kv "$I_CAL" "$L_DAYS" "$(flow_get dias)"
            kb_confirm hwid;;
    esac
    vp_end
}

# -------------------------------- DEMO --------------------------------
vp_demo() {
    vp_begin "$L_P_DEMO"
    b_txt "$L_ASK_DEMO_TOKEN"; b_txt "$L_HINT_NAME"
    vp_end
}

# ------------------------------- RENOVAR ------------------------------
vp_renovar() {
    vp_begin "$L_P_RENEW"
    b_kv "$I_USER" "$L_USER" "$(flow_get user)"
    case "$1" in
        modo)
            b_txt "$L_ASK_MODE"
            kb_row "$B_MODE_R" "fl:renovar:modo:R"
            kb_row "$B_MODE_M" "fl:renovar:modo:M"
            kb_row "$B_MODE_Q" "fl:renovar:modo:Q";;
        dias)
            b_txt "$L_ASK_DAYS"; kb_days renovar dias;;
        confirmar)
            b_txt "$L_CONFIRM_ASK"
            b_kv "$I_RENEW" "$L_MODE" "$(vp_modo_txt "$(flow_get modo)")"
            b_kv "$I_CAL" "$L_DAYS" "$(flow_get dias)"
            kb_confirm renovar;;
    esac
    vp_end
}

vp_modo_txt() { case "$1" in M) echo "$L_MODE_M";; Q) echo "$L_MODE_Q";; *) echo "$L_MODE_R";; esac; }

# ------------------------------- ADMINS -------------------------------
vp_admin() {
    vp_begin "$L_ADM_ADD_T"
    case "$1" in
        id) b_txt "$L_ASK_TGID"; b_txt "$L_HINT_TGID";;
        cred)
            b_kv "$I_ADMIN" "ID" "$(flow_get id)"
            b_txt "$L_ASK_CRED"
            kb_opts admin cred "5" 5 "10" 10 "20" 20 "50" 50 "∞" X;;
        confirmar)
            b_txt "$L_CONFIRM_ASK"
            b_kv "$I_ADMIN" "ID" "$(flow_get id)"
            b_kv "$I_CRED" "$L_CREDITS" "$(cred_txt "$(flow_get cred)")"
            kb_confirm admin;;
    esac
    vp_end
}

vp_credito() {
    vp_begin "$L_ADM_CRED_T"
    b_kv "$I_ADMIN" "ID" "$(flow_get id)"
    case "$1" in
        cant)
            b_txt "$L_ASK_CRED_ADD"
            kb_opts credito cant "5" 5 "10" 10 "20" 20 "50" 50 "100" 100;;
        confirmar)
            b_txt "$L_CONFIRM_ASK"
            b_kv "$I_CRED" "$L_ADDED" "$(flow_get cant)"
            kb_confirm credito;;
    esac
    vp_end
}

# ------------------------- RESTORE / V2RAY / PAYLOAD -------------------
vp_restore() {
    vp_begin "$L_RESTORE_T"
    b_txt "$L_ASK_URL"
    vp_end
}

vp_v2ray() {
    vp_begin "$L_V2_T"
    case "$1" in
        nombre) b_txt "$L_ASK_NAME"; b_txt "$L_HINT_NAME";;
        dias)
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_txt "$L_ASK_DAYS"; kb_days v2ray dias;;
        confirmar)
            b_txt "$L_CONFIRM_ASK"
            b_kv "$I_USER" "$L_USER" "$(flow_get nombre)"
            b_kv "$I_CAL" "$L_DAYS" "$(flow_get dias)"
            kb_confirm v2ray;;
    esac
    vp_end
}

vp_payload() {
    vp_begin "$L_PAY_T"
    case "$1" in
        host) b_txt "$L_ASK_HOST";;
        req)
            b_kv "$I_PORT" "Host" "$(flow_get host)"
            b_txt "$L_ASK_REQ"
            kb_opts payload req "GET" 1 "CONNECT" 2 "PUT" 3
            kb_opts payload req "OPTIONS" 4 "DELETE" 5 "HEAD" 6
            kb_opts payload req "TRACE" 7 "PROPATCH" 8 "PATCH" 9;;
        conex)
            b_kv "$I_PORT" "Host" "$(flow_get host)"
            b_kv "$I_PORT" "$L_REQ" "$(flow_get req)"
            b_txt "$L_ASK_CONN"
            kb_opts payload conex "REALDATA" 1 "NETDATA" 2 "RAW" 3;;
    esac
    vp_end
}
