#!/bin/bash
# =====================================================================
#  views/sistema.sh - VPS, puertos, precios, backup, v2ray, payloads
# =====================================================================

vista_vps() {
    ui_begin
    b_head "$L_VPS_T"
    b_kv "$I_SERVER" "$L_SYSTEM" "$R_SISTEMA"
    b_kv "$I_SERVER" "CPU" "$R_CPU"
    b_kv "$I_SERVER" "CPU ID" "$R_CPUID"
    b_kv "$I_SERVER" "RAM" "${R_RAM_U}/${R_RAM_T} MB (${L_FREE} ${R_RAM_L})"
    b_kv "$I_WAIT" "$L_UPTIME" "$R_UPTIME"
    b_kv "$I_SERVER" "$L_ARCH" "${R_ARCH} / ${R_CORES} cores"
    kb_row "$B_REFRESH" "sys:vps" "$B_HOME" "m:home"
    ui_flush
}

vista_puertos() {   # usa PRT_TCP PRT_UDP
    local e
    ui_begin
    b_head "$L_PORTS_T"
    for e in "${PRT_TCP[@]}"; do b_raw "${I_PORT} $(esc "${e%%|*}"): <code>${e#*|}</code> (TCP)"; done
    for e in "${PRT_UDP[@]}"; do b_raw "${I_PORT} $(esc "${e%%|*}"): <code>${e#*|}</code> (UDP)"; done
    (( ${#PRT_TCP[@]} + ${#PRT_UDP[@]} == 0 )) && b_txt "$L_PORTS_NONE"
    kb_row "$B_REFRESH" "sys:ports" "$B_HOME" "m:home"
    ui_flush
}

vista_precios() {
    ui_begin
    b_head "$L_PRICES_T"
    b_raw '$1.50 USD - 15 dias'
    b_raw '$3.00 USD - 120 dias'
    b_raw '$5.00 USD - 180 dias'
    b_raw '$12.00 USD - 365 dias'
    b_sep
    b_txt "$L_PRICES_NOTE"
    kb_nav "m:mas"
    ui_flush
}

vista_backup_menu() {
    ui_begin
    b_head "$L_BACKUP_T"
    b_txt "$L_BACKUP_HINT"
    kb_row "$B_BACKUP_NOW" "bk:run" "$B_RESTORE" "new:restore"
    kb_nav "m:mas"
    ui_flush
}

vista_backup_ok() {
    ui_begin
    b_head "$L_BACKUP_T"
    b_kv "$I_OK" "$L_USERS_N" "$R_N"
    b_txt "$L_BACKUP_SENT"
    kb_nav "bk:menu"
    ui_flush
}

vista_restore_ok() {
    ui_begin
    b_head "$L_RESTORE_T"
    b_kv "$I_OK" "$L_CREATED" "$R_OK"
    b_kv "$I_ERR" "$L_SKIPPED" "$R_SKIP"
    kb_nav "bk:menu"
    ui_flush
}

vista_v2ray() {
    ui_begin
    b_head "$L_V2_T"
    b_kv "$I_CRED" "$L_CREDITS" "$R_CRED"
    b_kv "$I_USER" "$L_USER" "$R_USER"
    b_kv "$I_CAL" "$L_EXPIRES" "$R_EXPIRA"
    b_raw "<code>$(esc "$R_LINK")</code>"
    [[ -n "$R_QR" ]] && b_raw "$(esc "$R_QR")"
    kb_row "$B_AGAIN" "new:v2ray" "$B_HOME" "m:home"
    ui_flush
}

vista_payload_ok() {
    ui_begin
    b_head "$L_PAY_T"
    b_txt "$L_PAY_SENT"
    kb_row "$B_AGAIN" "new:payload" "$B_HOME" "m:home"
    ui_flush
}
