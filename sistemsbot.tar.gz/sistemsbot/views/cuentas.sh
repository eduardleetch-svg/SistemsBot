#!/bin/bash
# =====================================================================
#  views/cuentas.sh - pantallas de cuentas (creacion, listas, detalle)
# =====================================================================

# Cuenta recien creada / renovada / demo
vista_cuenta() {
    local titulo again
    ui_begin
    case "$R_TIPO" in
        SSH)      titulo="$L_T_SSH";   again="new:ssh";;
        TOKEN)    titulo="$L_T_TOKEN"; again="new:token";;
        HWID)     titulo="$L_T_HWID";  again="new:hwid";;
        DEMO)     titulo="$L_T_DEMO";  again="new:demo";;
        RENOVADA) titulo="$(printf '%s (%s %s)' "$L_T_RENEW" "$R_DIAS" "$L_DAYS")"; again="usr:list:auto:1:ren";;
    esac
    b_head "$titulo"
    b_kv "$I_CRED" "$L_CREDITS" "$R_CRED"
    [[ "$R_TIPO" == "DEMO" ]] && b_kv "$I_WAIT" "$L_DEMOS_LEFT" "$R_RESTANTES"
    b_sep
    b_kv "$I_IP" "Host/IP" "$R_IP"
    b_kv "$I_USER" "$L_USER" "$R_USER"
    [[ "$R_TIPO" != "RENOVADA" ]] && b_kv "$I_KEY" "$R_ETQ" "$R_SECRET"
    b_kv "$I_CAL" "$L_EXPIRES" "$R_EXPIRA"
    [[ -n "$R_LIMITE" ]] && b_kv "$I_LIM" "$L_LIMIT" "$R_LIMITE"
    if [[ -n "$R_NS$R_PUB$R_PROTO" ]]; then
        b_sep
        [[ -n "$R_NS" ]]    && b_kv "$I_PORT" "NS" "$R_NS"
        [[ -n "$R_PUB" ]]   && b_kv "$I_KEY" "PUB" "$R_PUB"
        [[ -n "$R_PROTO" ]] && b_kv "$I_PORT" "$L_PROTOCOL" "$R_PROTO"
    fi
    kb_row "$B_AGAIN" "$again" "$B_HOME" "m:home"
    ui_flush
}

# Lista paginada. modo: ver | ren | del    scope: auto | all | mine
vista_lista() {   # modo scope pagina
    local modo="$1" scope="$2" pg="$3" n total start i dias title
    n=${#LST_USER[@]}
    total=$(( (n + PAGE_SIZE - 1) / PAGE_SIZE )); (( total < 1 )) && total=1
    (( pg > total )) && pg=$total
    (( pg < 1 )) && pg=1
    start=$(( (pg - 1) * PAGE_SIZE ))
    case "$modo" in
        ren) title="$L_LIST_REN";;
        del) title="$L_LIST_DEL";;
        *)   title="$L_LIST_VER";;
    esac
    ui_begin
    b_head "$title"
    if (( n == 0 )); then
        b_txt "$L_NO_USERS"
    else
        b_txt "${L_PAGE} ${pg}/${total} · ${n} ${L_USERS_N}"
        for (( i = start; i < start + PAGE_SIZE && i < n; i++ )); do
            dias="${LST_DIAS[$i]}"
            [[ "$dias" =~ ^[0-9]+$ ]] && dias="${dias}${L_D}"
            kb_row "${I_USER} ${LST_DISP[$i]} · ${dias}" "usr:${modo}:${LST_USER[$i]}"
        done
        kb_pager "usr:list:${scope}" "$pg" "$total" ":${modo}"
    fi
    kb_home
    ui_flush
}

vista_detalle() {   # usa R_* de core_cuenta_info
    local d="$R_DIAS_TXT"
    [[ "$d" =~ ^[0-9]+$ ]] && d="${d} ${L_DAYS}"
    ui_begin
    b_head "$L_DETAIL_T"
    b_kv "$I_USER" "$L_USER" "$R_USER"
    b_kv "$I_KEY" "$L_PASS" "$R_SECRET"
    b_kv "$I_CAL" "$L_EXPIRES" "$d"
    b_kv "$I_LIM" "$L_LIMIT" "$R_LIMITE"
    b_sep
    kb_row "$B_RENEWBTN" "usr:ren:${R_ACCOUNT}" "$B_DELETE" "usr:del:${R_ACCOUNT}"
    kb_row "$B_BACK" "usr:list:auto:1:ver" "$B_HOME" "m:home"
    ui_flush
}

vista_confirmar_borrar() {   # usuario
    ui_begin
    b_head "$L_DEL_T"
    b_txt "$L_DEL_ASK"
    b_kv "$I_USER" "$L_USER" "$1"
    kb_row "$B_DEL_YES" "usr:delok:$1" "$B_CANCEL" "usr:ver:$1"
    ui_flush
}

vista_borrada() {
    ui_begin
    b_head "$L_DELETED_T"
    b_kv "$I_OK" "$L_USER" "$R_USER"
    kb_row "$B_USERS" "usr:list:auto:1:ver" "$B_HOME" "m:home"
    ui_flush
}

vista_conectados() {   # usa CON_*
    local i n=${#CON_USER[@]}
    ui_begin
    b_head "$L_ONLINE_T"
    if (( n == 0 )); then
        b_txt "$L_ONLINE_NONE"
    else
        for (( i = 0; i < n; i++ )); do
            b_kv "$I_ONLINE" "${CON_DISP[$i]}" "${CON_N[$i]} ${L_CONN}"
        done
    fi
    kb_row "$B_REFRESH" "con:list" "$B_HOME" "m:home"
    ui_flush
}
