#!/bin/bash
[[ $EUID -eq 0 ]] || { echo "Ejecuta como root"; exit 1; }
systemctl disable --now sistemsbot 2>/dev/null
rm -f /etc/systemd/system/sistemsbot.service /usr/local/bin/sistemsbot
systemctl daemon-reload
rm -rf /opt/sistemsbot
echo "Eliminado el programa. Se conservan /etc/sistemsbot y /etc/adm-lite (tus datos). Bórralos a mano si quieres."
