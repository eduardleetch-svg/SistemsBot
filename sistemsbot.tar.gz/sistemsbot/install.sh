#!/bin/bash
# Instalador de sistemsbot (Ubuntu/Debian, como root)
set -e
[[ $EUID -eq 0 ]] || { echo "Ejecuta como root"; exit 1; }
REPO="eduardleetch-svg/SistemsBot"
SRC="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
# Si se ejecuta con curl (sin archivos al lado), baja el codigo de GitHub
if [[ ! -f "$SRC/bot.sh" ]]; then
    apt-get update -y >/dev/null; apt-get install -y curl tar >/dev/null
    SRC="$(mktemp -d)"
    curl -fsSL "https://github.com/$REPO/archive/refs/heads/main.tar.gz" | tar -xz -C "$SRC" --strip-components=1 \
        || { echo "No pude bajar el repo"; exit 1; }
fi
DEST=/opt/sistemsbot
CONF_DIR=/etc/sistemsbot

echo "== Dependencias =="
export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a
apt-get update -y >/dev/null
apt-get install -y curl jq at lsof net-tools openssl wget util-linux procps screen >/dev/null
systemctl enable --now atd >/dev/null 2>&1 || true

echo "== Archivos =="
mkdir -p "$DEST" "$CONF_DIR"
cp -a "$SRC"/. "$DEST"/
rm -rf "$DEST/tests" "$DEST/.git"
chmod +x "$DEST/bot.sh" "$DEST/bin/sistemsbot"
ln -sf "$DEST/bin/sistemsbot" /usr/local/bin/sistemsbot

if [[ ! -f "$CONF_DIR/bot.conf" ]]; then
    read -rp "Token del bot (@BotFather): " TOKEN
    read -rp "Tu ID de Telegram (dueño): " OWNER
    [[ "$OWNER" =~ ^[0-9]+$ ]] || { echo "ID inválido"; exit 1; }
    [[ "$TOKEN" =~ ^[0-9]+:[A-Za-z0-9_-]{30,}$ ]] || { echo "Token con formato inválido"; exit 1; }
    cp "$DEST/config/bot.conf.example" "$CONF_DIR/bot.conf"
    sed -i "s|^BOT_TOKEN=.*|BOT_TOKEN=\"$TOKEN\"|; s|^OWNER_ID=.*|OWNER_ID=\"$OWNER\"|" "$CONF_DIR/bot.conf"
    chmod 600 "$CONF_DIR/bot.conf"
else
    echo "Config existente conservada: $CONF_DIR/bot.conf"
    OWNER="$(grep -oP '^OWNER_ID="\K[0-9]+' "$CONF_DIR/bot.conf" || true)"
fi

# datos compatibles con el bot anterior
DATA_DIR=/etc/adm-lite; EJE=/bin/ejecutar
mkdir -p "$DATA_DIR" "$EJE"
touch "$DATA_DIR/liberados" "$DATA_DIR/registerBOT.log" "$EJE/demos"
if [[ -n "$OWNER" ]] && ! grep -q "^$OWNER|" "$DATA_DIR/liberados"; then echo "$OWNER|X" >> "$DATA_DIR/liberados"; fi
[[ -s "$EJE/IPcgh" ]] || wget -qO- -T 5 ipv4.icanhazip.com > "$EJE/IPcgh" 2>/dev/null || true
touch "$CONF_DIR/bottokens"; chmod 600 "$CONF_DIR/bottokens"

cat > /etc/systemd/system/sistemsbot.service <<UNIT
[Unit]
Description=sistemsbot (Telegram)
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/bin/bash $DEST/bot.sh
Restart=always
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now sistemsbot
sleep 2
systemctl --no-pager -l status sistemsbot | head -8
echo
echo "Listo. Comandos: sistemsbot {start|stop|restart|status|logs|theme|config}"
echo "Abre tu bot en Telegram y envía /start"
