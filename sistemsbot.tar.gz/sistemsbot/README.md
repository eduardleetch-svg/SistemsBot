# sistemsbot

Bot de Telegram para administrar cuentas SSH/Token/HWID en un VPS, modular.

## Instalar (Ubuntu/Debian, root)
    bash <(curl -fsSL https://raw.githubusercontent.com/eduardleetch-svg/SistemsBot/main/install.sh)

## Estructura (qué tocar para cada cosa)
| Quiero cambiar…              | Archivo                         |
|------------------------------|---------------------------------|
| Colores, iconos, animación   | `themes/*.sh` (copia uno y cambia) |
| Textos / idioma              | `lang/es.sh`                    |
| Qué botones tiene el menú    | `menus/principal.sh`            |
| Pasos de un asistente        | `flows/*.sh` (lógica) + `views/prompts.sh` (pantalla) |
| Cómo se ve una pantalla      | `views/*.sh`                    |
| Reglas de negocio            | `core/*.sh`                     |
| Conectar comando/botón       | `modules/*.sh`                  |

Regla: `core/` nunca envía mensajes; `views/` nunca calcula; los temas solo definen variables.

## Nuevo tema
Copia `themes/classic.sh` a `themes/mitema.sh`, cambia valores. Aparece solo en el botón Tema.

## CLI
`sistemsbot start|stop|restart|status|logs|theme [nombre]|config|update`

## Pruebas
`bash tests/check_vars.sh` y `bash tests/integration.sh` (Telegram simulado).
