#!/bin/bash
# =====================================================================
#  lang/es.sh - TODOS los textos (espanol). Para otro idioma: copia a
#  lang/en.sh, traduce y pon LANG_BOT=en en bot.conf
# =====================================================================
L_APP="SISTEMSBOT"
L_ROLE="Rol"; L_ROLE_OWNER="Dueño"; L_ROLE_SUPER="Super admin"; L_ROLE_RESELLER="Revendedor"
L_CREDITS="Créditos"
L_MENU_HINT="Elige una opción:"
L_MORE_T="Más opciones"; L_MORE_HINT="Herramientas avanzadas:"
L_BLOCKED_T="Acceso restringido"
L_BLOCKED_1="No tienes autorización para usar este bot."
L_BLOCKED_2="Envía tu ID al administrador para que te dé acceso."
L_ACCESS_OK="✅ Acceso activado."
L_THEME_T="Tema"; L_THEME_HINT="Elige cómo quieres ver el bot:"; L_THEME_SET="Tema aplicado."
L_CANCELLED="Operación cancelada."
L_EXPIRED="Esta pantalla expiró. Empieza de nuevo."
L_LOADING="Cargando"; L_CREATING="Creando cuenta"; L_RENEWING="Renovando"
L_DELETING="Eliminando"; L_RESTORING="Restaurando"

# errores
L_ERR_T="Error"
L_ERR_NOPERM="No tienes permiso para esta acción."
L_ERR_UNKNOWN="Comando desconocido. Usa /start."
L_ERR_INVALID="Datos inválidos."
L_ERR_EXISTS="Ese usuario ya existe."
L_ERR_NOCRED="No tienes créditos suficientes."
L_ERR_NOTFOUND="Usuario no encontrado."
L_ERR_DAYS="Cantidad de días inválida."
L_ERR_DEMOMAX="Límite de demos activas alcanzado."
L_ERR_OWNER="Esa operación es solo del dueño."
L_ERR_UNLIMITED="El administrador ilimitado no tiene créditos que modificar."
L_ERR_GENERIC="No se pudo completar la operación."
L_ERR_NAME="Nombre inválido (3-32: letras, números, . _ -)."
L_ERR_PASS="Clave inválida (3-64 caracteres)."
L_ERR_DAYS_IN="Días inválidos (1-3650)."
L_ERR_LIMIT="Límite inválido (1-999)."
L_ERR_IDENT="Identificador inválido."
L_ERR_ID="ID de Telegram inválido (solo números)."
L_ERR_AMOUNT="Cantidad inválida (1-100000)."
L_ERR_URL="Debe ser una URL http(s)."
L_ERR_HOST="Host inválido."
L_USE_BUTTONS="Usa los botones de abajo."

# comunes
L_USER="Usuario"; L_PASS="Clave"; L_MAX="Máximo"; L_DAYS="días"; L_D="d"
L_EXPIRES="Vence"; L_LIMIT="Límite"; L_PROTOCOL="Protocolo"
L_DEMOS_LEFT="Demos restantes"
L_FREE="libre"; L_UPTIME="Activo"; L_ARCH="Arquitectura"; L_SYSTEM="Sistema"
L_CONFIRM_ASK="Confirma los datos:"

# titulos de resultado
L_T_SSH="Cuenta SSH creada"; L_T_TOKEN="Cuenta TOKEN creada"; L_T_HWID="Cuenta HWID creada"
L_T_DEMO="Demo creada"; L_T_RENEW="Cuenta renovada"

# listas
L_LIST_VER="Usuarios"; L_LIST_REN="Renovar: elige usuario"; L_LIST_DEL="Eliminar: elige usuario"
L_NO_USERS="No hay usuarios."; L_PAGE="Página"; L_USERS_N="usuarios"
L_DETAIL_T="Detalle de cuenta"
L_DEL_T="Eliminar cuenta"; L_DEL_ASK="¿Seguro que quieres eliminar a este usuario?"
L_DELETED_T="Cuenta eliminada"

# conectados / sistema
L_ONLINE_T="Usuarios conectados"; L_ONLINE_NONE="Nadie conectado."; L_CONN="conexiones"
L_VPS_T="Información del VPS"
L_PORTS_T="Puertos activos"; L_PORTS_NONE="Sin puertos detectados."
L_PRICES_T="Precios"; L_PRICES_NOTE="Define tus precios en $DATA_DIR/precios.txt"

# backup
L_BACKUP_T="Respaldo"; L_BACKUP_HINT="Genera y recibe un respaldo de usuarios por este chat."
L_BACKUP_SENT="Respaldo enviado."; L_BACKUP_CAPTION="Respaldo de usuarios"
L_RESTORE_T="Restauración"; L_CREATED="Creados"; L_SKIPPED="Omitidos"

# v2ray / payload
L_V2_T="Cuenta V2Ray"; L_PAY_T="Payload generado"; L_PAY_SENT="Archivo enviado."

# admin
L_ADM_T="Administradores"; L_ADM_HINT="Gestiona revendedores y créditos."
L_ADM_LIST_T="Lista de administradores"; L_ADM_NONE="Sin administradores."
L_CRED_WORD="créditos"; L_ADM_PICK="Elige un administrador:"
L_ADM_KILL_T="Quitar administrador"; L_ADM_KILL_ASK="¿Quitar a este administrador?"
L_ADM_CRED_T="Sumar créditos"
L_ADM_ADDED_T="Administrador agregado"; L_ADM_CREDITED_T="Créditos sumados"
L_ADM_REMOVED_T="Administrador eliminado"; L_ADDED="Sumados"; L_ADM_ADD_T="Agregar administrador"
L_ADM_NOTICE="Aviso de tu administrador:"

# asistentes
L_P_ADD="Nueva cuenta SSH"; L_P_TOKEN="Nueva cuenta TOKEN"; L_P_HWID="Nueva cuenta HWID"
L_P_DEMO="Cuenta demo"; L_P_RENEW="Renovar cuenta"
L_DEMO_HINT="Elige el tipo de demo:"
L_ASK_NAME="Escribe el nombre de usuario:"; L_ASK_NAME_CLIENT="Escribe el nombre del cliente:"
L_HINT_NAME="3-32 caracteres: letras, números, . _ -"
L_ASK_PASS="Escribe la clave o pulsa Generar:"; L_HINT_PASS="3-64 caracteres. Tu mensaje se borrará."
L_ASK_DAYS="¿Cuántos días?"; L_ASK_LIMIT="¿Cuántas conexiones simultáneas?"
L_ASK_TOKEN="Escribe el token del cliente:"; L_ASK_HWID="Escribe el HWID del cliente:"
L_ASK_DEMO_TOKEN="Escribe el token para la demo:"
L_ASK_MODE="¿Cómo quieres renovar?"
L_MODE="Modo"; L_MODE_R="Estándar"; L_MODE_M="Mensual"; L_MODE_Q="Quincenal"
L_ASK_TGID="Escribe el ID de Telegram del revendedor:"; L_HINT_TGID="Solo números."
L_ASK_CRED="¿Cuántos créditos tendrá?"; L_ASK_CRED_ADD="¿Cuántos créditos sumar?"
L_ASK_URL="Envía la URL del respaldo (http/https):"
L_ASK_HOST="Escribe el host o dominio:"
L_ASK_REQ="Elige el tipo de petición:"; L_ASK_CONN="Elige el tipo de conexión:"
L_REQ="Petición"

# avisos al dueno
L_NOTIFY_CREATED="creó"; L_NOTIFY_RENEWED="renovó"; L_NOTIFY_DEMO="demo"
