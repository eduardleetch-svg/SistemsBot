#!/bin/bash
# =====================================================================
#  modules/menu.sh - /start, menus, temas, cancelar, acceso por clave
# =====================================================================

cmd_register "start ayuda help menu" h_start   public
cmd_register "cancelar cancel"       h_cancel  reseller
cmd_register "tema theme"            h_tema    reseller
cmd_register "access loguin"         h_access  public
cb_register  "m"                     cb_menu   reseller
cb_register  "fl"                    cb_flow   reseller

h_start() {
    if [[ -z "$CRED" ]]; then vista_bloqueado; else vista_menu; fi
}

h_cancel() {
    flow_end
    L_NOTE="$L_CANCELLED"
    vista_menu
}

h_tema() { vista_temas; }

h_access() {
    tg_delete "$CTX_CHAT" "$CTX_MID"     # la clave no debe quedar en el chat
    UI_MID=""
    if core_activar_acceso "${CTX_ARGS[0]}" "${CTX_ARGS[1]}"; then
        CRED="X"
        L_NOTE="$L_ACCESS_OK"
        vista_menu
    elif [[ "$R_ESTADO" == "existe" ]]; then
        vista_menu
    else
        R_ESTADO=invalido; R_MSG=""
        vista_error
    fi
}

cb_menu() {
    case "${CB[1]}" in
        home) vista_menu;;
        mas)
            nivel_ok super && vista_menu_mas || vista_sin_permiso;;
        tema)
            if [[ -n "${CB[2]}" ]]; then
                if tema_valido "${CB[2]}" && [[ -f "$SB_HOME/themes/${CB[2]}.sh" ]]; then
                    printf '%s' "${CB[2]}" > "$PREF_DIR/$CTX_UID.theme"
                    theme_load
                    L_NOTE="$L_THEME_SET"
                fi
                vista_menu
            else
                vista_temas
            fi;;
        noop) :;;
    esac
}
