#!/bin/bash
# =====================================================================
#  modules/admin.sh - conectados, administradores y creditos (comandos + botones)
# =====================================================================

cmd_register "conectados activos"  h_conectados  super
cmd_register "usconnect"           h_usconnect   reseller
cmd_register "liberados libres"    h_liberados   super
cmd_register "aggadm"              h_aggadm      dueno
cmd_register "creditos"            h_creditos    dueno
cmd_register "admkill"             h_admkill     dueno
cb_register  "con"                 cb_con        reseller
cb_register  "adm"                 cb_adm        dueno

# ------------------------------ conectados ----------------------------
h_conectados() { core_conectados all  && vista_conectados; }
h_usconnect()  { core_conectados mine && vista_conectados; }

cb_con() {
    local sc=mine
    [[ "$CRED" == "X" ]] && sc=all
    ui_anim "$L_LOADING"
    core_conectados "$sc" && vista_conectados
}

# ----------------------------- administradores ------------------------
h_liberados() {
    core_admin_listar
    vista_admin_lista
}

h_aggadm() {
    if [[ -z "${CTX_ARGS[0]}" ]]; then flow_start admin id; return 0; fi
    if core_admin_agregar "${CTX_ARGS[0]}" "${CTX_ARGS[1]}"; then
        vista_admin_resultado agregado
        vista_avisar_admin "$R_ID" "$L_ADM_ADDED_T"
    else
        vista_error
    fi
}

h_creditos() {
    if [[ -z "${CTX_ARGS[0]}" || -z "${CTX_ARGS[1]}" ]]; then
        core_admin_listar; vista_admin_elegir cr; return 0
    fi
    if core_admin_creditos "${CTX_ARGS[0]}" "${CTX_ARGS[1]}"; then
        vista_admin_resultado creditos
        vista_avisar_admin "$R_ID" "$L_ADM_CREDITED_T"
    else
        vista_error
    fi
}

h_admkill() {
    if [[ -z "${CTX_ARGS[0]}" ]]; then core_admin_listar; vista_admin_elegir kill; return 0; fi
    if core_admin_quitar "${CTX_ARGS[0]}"; then
        vista_admin_resultado quitado
        vista_avisar_admin "$R_ID" "$L_ADM_REMOVED_T"
    else
        vista_error
    fi
}

cb_adm() {
    local sub="${CB[1]}" i="${CB[2]}"
    case "$sub" in
        menu) vista_admin_menu;;
        list) core_admin_listar; vista_admin_lista;;
        pick) core_admin_listar; vista_admin_elegir "${CB[2]}";;
        cr)   # adm:cr:<id>  -> asistente de creditos para ese reseller
            if id_valido "$i" && existe_admin "$i"; then flow_start credito cant "id=$i"
            else R_ESTADO=no_encontrado; R_USER="$i"; vista_error; fi;;
        kill)
            if id_valido "$i" && existe_admin "$i"; then vista_admin_confirmar_quitar "$i"
            else R_ESTADO=no_encontrado; R_USER="$i"; vista_error; fi;;
        killok)
            if core_admin_quitar "$i"; then
                vista_admin_resultado quitado
                vista_avisar_admin "$R_ID" "$L_ADM_REMOVED_T"
            else
                vista_error
            fi;;
    esac
}
