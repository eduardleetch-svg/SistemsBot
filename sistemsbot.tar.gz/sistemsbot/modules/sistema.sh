#!/bin/bash
# =====================================================================
#  modules/sistema.sh - VPS, puertos, precios, backup/restore, v2ray, payloads
# =====================================================================

cmd_register "infovps"          h_infovps    super
cmd_register "puertos"          h_puertos    reseller
cmd_register "precios"          h_precios    super
cmd_register "backup"           h_backup     dueno
cmd_register "restore"          h_restore    dueno
cmd_register "v2ray addv2"      h_v2ray      super
cmd_register "gerar pay"        h_gerar      super
cb_register  "sys"              cb_sys       reseller
cb_register  "bk"               cb_bk        dueno

h_infovps()  { core_vps && vista_vps; }
h_puertos()  { core_puertos; vista_puertos; }
h_precios()  { vista_precios; }

cb_sys() {
    case "${CB[1]}" in
        vps)   req_nivel super && { ui_anim "$L_LOADING"; core_vps; vista_vps; };;
        ports) ui_anim "$L_LOADING"; core_puertos; vista_puertos;;
        price) req_nivel super && vista_precios;;
    esac
}

# ----------------------------- backup / restore -----------------------
_hacer_backup() {
    tg_action "$CTX_CHAT" upload_document
    if core_backup; then
        # Solo al privado de quien lo pide; nada se publica en la web
        tg_doc "$CTX_UID" "$R_FILE" "$L_BACKUP_CAPTION ($R_N)"
        rm -f "$R_FILE"
        vista_backup_ok
    else
        vista_error
    fi
}

h_backup() { _hacer_backup; }

h_restore() {
    if [[ -z "${CTX_ARGS[0]}" ]]; then flow_start restore url; return 0; fi
    if core_restore "${CTX_ARGS[0]}"; then vista_restore_ok; else vista_error; fi
}

cb_bk() {
    case "${CB[1]}" in
        menu) vista_backup_menu;;
        run)  ui_anim "$L_LOADING"; _hacer_backup;;
    esac
}

# ------------------------------ v2ray / payload -----------------------
h_v2ray() {
    if ! core_v2ray_disponible; then R_ESTADO=error; R_MSG="v2ray/bot_codes"; vista_error; return 0; fi
    if (( ${#CTX_ARGS[@]} >= 2 )); then
        if core_crear_v2ray "${CTX_ARGS[0]}" "${CTX_ARGS[1]}"; then vista_v2ray; else vista_error; fi
    else
        flow_start v2ray nombre
    fi
}

h_gerar() {
    if (( ${#CTX_ARGS[@]} >= 3 )); then
        if core_payload "${CTX_ARGS[0]}" "${CTX_ARGS[1]}" "${CTX_ARGS[2]}"; then
            tg_doc "$CTX_CHAT" "$R_FILE"
            vista_payload_ok
        else
            vista_error
        fi
    else
        flow_start payload host
    fi
}
