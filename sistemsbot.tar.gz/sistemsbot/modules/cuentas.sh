#!/bin/bash
# =====================================================================
#  modules/cuentas.sh - comandos y botones de cuentas
#  (pega el mensaje/boton con core/ y views/; aqui no hay logica de cuentas)
# =====================================================================

cmd_register "agregar add"          h_agregar    reseller
cmd_register "token"                h_token      reseller
cmd_register "hwid"                 h_hwid       reseller
cmd_register "demo"                 h_demo       reseller
cmd_register "renovar"              h_renovar    reseller
cmd_register "renovarm"             h_renovar_m  reseller
cmd_register "renovarq"             h_renovar_q  reseller
cmd_register "borrar dell"          h_borrar     reseller
cmd_register "usuarios"             h_usuarios   super
cmd_register "usreg"                h_usreg      reseller
cb_register  "new"                  cb_new       reseller
cb_register  "usr"                  cb_usr       reseller

# Resultado de una creacion directa (sin asistente)
_mostrar_resultado() {   # ok? -> vista_cuenta | vista_error  (+ aviso al dueno)
    if (( $1 == 0 )); then
        vista_cuenta
        vista_notificar_dueno "$L_NOTIFY_CREATED" "$R_USER" "$R_DIAS"
    else
        vista_error
    fi
}

# --------------------------- comandos escritos ------------------------
h_agregar() {
    if (( ${#CTX_ARGS[@]} >= 1 )); then
        # /agregar nombre [clave] [dias] [limite]  (lo que falte usa valores por defecto)
        tg_delete "$CTX_CHAT" "$CTX_MID"      # no dejar la clave en el chat
        UI_MID=""
        core_crear_ssh "${CTX_ARGS[0]}" "${CTX_ARGS[1]:-$(gen_pass)}" \
            "${CTX_ARGS[2]:-${DEFAULT_DIAS:-30}}" "${CTX_ARGS[3]:-${DEFAULT_LIMITE:-1}}"
        _mostrar_resultado $?
    else
        flow_start agregar nombre
    fi
}

h_token() {
    if (( ${#CTX_ARGS[@]} >= 2 )); then
        local dias="${CTX_ARGS[2]}"
        [[ -z "$dias" ]] && dias=$(( $(date -d "$(date +%Y-%m-01) +1 month -1 day" +%-d) + 1 ))
        core_crear_token "${CTX_ARGS[0]}" "${CTX_ARGS[1]}" "$dias"
        _mostrar_resultado $?
    else
        flow_start token nombre
    fi
}

h_hwid() {
    if (( ${#CTX_ARGS[@]} >= 2 )); then
        core_crear_hwid "${CTX_ARGS[0]}" "${CTX_ARGS[1]}" "${CTX_ARGS[2]:-30}"
        _mostrar_resultado $?
    else
        flow_start hwid nombre
    fi
}

h_demo() {
    core_crear_demo "${CTX_ARGS[0]}"
    _mostrar_resultado $?
}

_renovar_cmd() {   # modo
    local modo="$1"
    if (( ${#CTX_ARGS[@]} >= 2 )); then
        core_renovar "$modo" "${CTX_ARGS[0]}" "${CTX_ARGS[1]}"
        if (( $? == 0 )); then
            vista_cuenta
            vista_notificar_dueno "$L_NOTIFY_RENEWED" "$R_USER" "$R_DIAS"
        else
            vista_error
        fi
    elif (( ${#CTX_ARGS[@]} == 1 )) && puede_gestionar "${CTX_ARGS[0]}"; then
        flow_start renovar modo "user=${CTX_ARGS[0]}"
    else
        core_listar auto && vista_lista ren auto 1
    fi
}
h_renovar()   { _renovar_cmd ""; }
h_renovar_m() { _renovar_cmd "M"; }
h_renovar_q() { _renovar_cmd "Q"; }

h_borrar() {
    if [[ -z "${CTX_ARGS[0]}" ]]; then
        _lista_scope auto && vista_lista del auto 1
        return 0
    fi
    if core_borrar "${CTX_ARGS[0]}"; then vista_borrada; else vista_error; fi
}

# Resuelve el alcance de una lista: auto = todo (super) o lo propio (reseller)
_lista_scope() {
    local sc="$1"
    if [[ "$sc" == "auto" ]]; then
        [[ "$CRED" == "X" ]] && sc="all" || sc="mine"
    fi
    [[ "$sc" == "all" || "$sc" == "mine" ]] || return 1
    core_listar "$sc"
}

h_usuarios() { _lista_scope all && vista_lista ver auto 1; }
h_usreg()    { _lista_scope mine && vista_lista ver mine 1; }

# ------------------------------- botones ------------------------------
req_nivel() { nivel_ok "$1" || { vista_sin_permiso; return 1; }; }

vista_demo_menu() {
    ui_begin
    b_head "$L_P_DEMO"
    b_txt "$L_DEMO_HINT"
    kb_row "$B_DEMO_NORMAL" "new:demonormal" "$B_DEMO_TOKEN" "new:demotoken"
    kb_nav "m:home"
    ui_flush
}

cb_new() {
    case "${CB[1]}" in
        ssh)    flow_start agregar nombre;;
        token)  flow_start token nombre;;
        hwid)   flow_start hwid nombre;;
        demo)   vista_demo_menu;;
        demonormal)
            ui_anim "$L_CREATING"
            core_crear_demo ""
            _mostrar_resultado $?;;
        demotoken) flow_start demo token;;
        v2ray)   req_nivel super  && core_v2ray_disponible && flow_start v2ray nombre;;
        payload) req_nivel super  && flow_start payload host;;
        restore) req_nivel dueno  && flow_start restore url;;
        admin)   req_nivel dueno  && flow_start admin id;;
    esac
}

cb_usr() {
    local sub="${CB[1]}" u="${CB[2]}"
    case "$sub" in
        list)   # usr:list:<scope>:<pagina>:<modo>
            local sc="${CB[2]:-auto}" pg="${CB[3]:-1}" modo="${CB[4]:-ver}"
            [[ "$pg" =~ ^[0-9]{1,4}$ ]] || pg=1
            [[ "$modo" == @(ver|ren|del) ]] || modo=ver
            if _lista_scope "$sc"; then vista_lista "$modo" "$sc" "$pg"; else vista_sin_permiso; fi;;
        ver)
            if core_cuenta_info "$u"; then vista_detalle; else R_USER="$u"; vista_error; fi;;
        ren)
            if nombre_seguro "$u" && puede_gestionar "$u"; then
                flow_start renovar modo "user=$u"
            else
                R_ESTADO=no_encontrado; R_USER="$u"; vista_error
            fi;;
        del)
            if nombre_seguro "$u" && puede_gestionar "$u"; then
                vista_confirmar_borrar "$u"
            else
                R_ESTADO=no_encontrado; R_USER="$u"; vista_error
            fi;;
        delok)
            ui_anim "$L_DELETING"
            if core_borrar "$u"; then vista_borrada; else vista_error; fi;;
    esac
}
