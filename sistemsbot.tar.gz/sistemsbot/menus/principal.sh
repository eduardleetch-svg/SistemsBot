#!/bin/bash
# =====================================================================
#  menus/principal.sh - botones del menu principal (una linea por boton)
#  menu_btn  <menu>  <nivel>  <fila>  <etiqueta_del_tema>  <callback>  [condicion]
#  nivel: reseller | super | dueno      etiqueta: nombre de variable B_* del tema
# =====================================================================

menu_btn principal reseller 1 B_USERS   "usr:list:auto:1:ver"
menu_btn principal reseller 1 B_ADD     "new:ssh"
menu_btn principal reseller 2 B_TOKEN   "new:token"
menu_btn principal reseller 2 B_HWID    "new:hwid"
menu_btn principal reseller 3 B_DEMO    "new:demo"
menu_btn principal reseller 3 B_RENEW   "usr:list:auto:1:ren"
menu_btn principal reseller 4 B_ONLINE  "con:list"
menu_btn principal reseller 4 B_DELETE  "usr:list:auto:1:del"
menu_btn principal super    5 B_VPS     "sys:vps"
menu_btn principal reseller 5 B_PORTS   "sys:ports"
menu_btn principal super    6 B_MORE    "m:mas"
menu_btn principal reseller 6 B_THEME   "m:tema"

# ---- submenu "Mas" ----
menu_btn mas super 1 B_V2RAY    "new:v2ray"   core_v2ray_disponible
menu_btn mas super 1 B_PAYLOAD  "new:payload"
menu_btn mas dueno 2 B_ADMIN    "adm:menu"
menu_btn mas dueno 2 B_BACKUP   "bk:menu"
menu_btn mas super 3 B_PRICES   "sys:price"
