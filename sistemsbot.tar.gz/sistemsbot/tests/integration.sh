#!/bin/bash
# Prueba de integracion: bot.sh real + Telegram simulado
T="$(cd "$(dirname "$0")" && pwd)"; SB="$(dirname "$T")"
W="$(mktemp -d)"; export FAKE_DIR="$W/fake"; mkdir -p "$FAKE_DIR/queue"
OWN=1518767155; BAD=999
cat > "$W/bot.conf" <<C
BOT_TOKEN="123:TESTTOKENTESTTOKENTESTTOKENTESTTOKEN"
OWNER_ID="$OWN"
ANIMATIONS="off"
DATA_DIR="$W/data"; EJE_DIR="$W/eje"; LOG_FILE="$W/bot.log"
LOCK="$W/lock"; LOCKDIR="$W/lockdir"
C
n=0
msg() { n=$((n+1)); printf '{"ok":true,"result":[{"update_id":%d,"message":{"message_id":%d,"from":{"id":%s,"is_bot":false,"first_name":"A","username":"u%s"},"chat":{"id":%s,"type":"private"},"date":1,"text":"%s"}}]}' $n $((n+500)) $1 $1 $1 "$2" > "$FAKE_DIR/queue/$(printf %03d $n).json"; }
cbk() { n=$((n+1)); printf '{"ok":true,"result":[{"update_id":%d,"callback_query":{"id":"cb%d","from":{"id":%s,"is_bot":false,"first_name":"A","username":"u%s"},"message":{"message_id":300,"chat":{"id":%s,"type":"private"},"date":1,"text":"x"},"chat_instance":"1","data":"%s"}}]}' $n $n $1 $1 $1 "$2" > "$FAKE_DIR/queue/$(printf %03d $n).json"; }

msg $BAD "/start"
msg $BAD "/agregar a b 1 1"
msg $OWN "/start"
cbk $OWN "new:ssh"
msg $OWN "sbtest1"
cbk $OWN "fl:agregar:clave:__gen"
cbk $OWN "fl:agregar:dias:7"
cbk $OWN "fl:agregar:limite:1"
cbk $OWN "fl:agregar:confirmar:ok"
cbk $OWN "usr:list:auto:1:ver"
cbk $OWN "usr:ver:sbtest1"
cbk $OWN "usr:del:sbtest1"
cbk $OWN "usr:delok:sbtest1"
cbk $OWN "m:tema"
cbk $OWN "m:tema:neon"
cbk $OWN "m:mas"
cbk $OWN "sys:ports"
cbk $OWN "bk:run"
msg $OWN "/agregar sbtest2 Pa+ss=1 5 2"
msg $OWN "/agregar sbtest3"
cbk $OWN "new:ssh"
msg $OWN "sbtest4"
cbk $OWN "fl:agregar:clave:__fast"
msg $OWN "/borrar sbtest2"
msg $OWN "/borrar sbtest3"
msg $OWN "/borrar sbtest4"
msg $OWN "/cosa"
cbk $BAD "adm:menu"

PATH="$T/fake:$PATH" SB_CONF="$W/bot.conf" SB_HOME="$SB" timeout 75 bash "$SB/bot.sh" > "$W/out.txt" 2>&1
echo "--- salida"; cat "$W/out.txt"
echo "--- llamadas"; cut -c1-230 "$FAKE_DIR/log" | grep -v getUpdates
echo "--- log bot"; cat "$W/bot.log" 2>/dev/null
echo "--- usuarios residuales"; getent passwd | grep -E '^sbtest' || echo ninguno
echo "W=$W"
