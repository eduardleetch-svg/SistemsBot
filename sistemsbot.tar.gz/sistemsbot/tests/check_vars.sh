#!/bin/bash
# Verifica que toda variable L_/I_/B_/T_ usada este definida en lang y en cada tema
cd "$(dirname "$0")/.." || exit 1
used=$(grep -rhoE '\b(L|I|B|T)_[A-Z0-9_]+' views flows modules menus core lib/flow.sh lib/router.sh | sort -u)
rc=0
for v in $used; do
  case $v in L_NOTE) continue;; esac
  if [[ $v == L_* ]]; then grep -q "^$v=\|[ ;]$v=" lang/es.sh || { echo "FALTA lang: $v"; rc=1; }
  else for t in themes/*.sh; do grep -q "^$v=\|[ ;]$v=" $t || { echo "FALTA $t: $v"; rc=1; }; done; fi
done
exit $rc
